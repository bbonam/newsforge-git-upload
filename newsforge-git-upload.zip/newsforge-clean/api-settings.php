<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_admin();

// Handle save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_key'])) {
    $provider = $_POST['provider'] ?? '';
    $key      = trim($_POST['api_key'] ?? '');
    if (in_array($provider, ['claude','openai','gemini','newsapi']) && $key) {
        $encrypted = encrypt_key($key);
        Database::query(
            "INSERT INTO api_settings (provider_name,api_key,status) VALUES (?,?,'active')
             ON DUPLICATE KEY UPDATE api_key=?, status='active', updated_date=NOW()",
            [$provider, $encrypted, $encrypted]
        );
        log_activity('API Key Update', "Updated $provider API key");
        $saveMsg = ucfirst($provider) . ' API key saved successfully!';
    }
}

$keys = [];
foreach (Database::query("SELECT * FROM api_settings")->fetchAll() as $r) {
    $keys[$r['provider_name']] = $r;
}

$pageTitle  = 'API Settings';
$activePage = 'api-settings';
include __DIR__ . '/includes/layout.php';
?>

<?php if (isset($saveMsg)): ?>
  <div style="background:#d1fae5;color:#065f46;padding:12px 16px;border-radius:8px;margin-bottom:20px;font-size:13.5px"><i class="fa fa-check-circle" style="margin-right:8px"></i><?= htmlspecialchars($saveMsg) ?></div>
<?php endif; ?>

<div class="grid-2">
<div>
<div class="card mb-4">
  <div class="card-header"><i class="fa fa-key" style="color:#e94560;margin-right:8px"></i>AI API Keys</div>
  <div class="card-body">
    <div style="background:#eff6ff;border-radius:8px;padding:12px;margin-bottom:20px;font-size:13px;color:#1e40af"><i class="fa fa-shield-alt" style="margin-right:6px"></i>Keys are encrypted with AES-256 before database storage</div>

    <?php
    $providers = [
      'claude' => ['label'=>'Anthropic Claude','model'=>ANTHROPIC_MODEL,'icon'=>'C','color'=>'#fff5f7','tc'=>'#e94560','url'=>'https://console.anthropic.com/'],
      'openai' => ['label'=>'OpenAI','model'=>OPENAI_MODEL,'icon'=>'O','color'=>'#eff6ff','tc'=>'#3b82f6','url'=>'https://platform.openai.com/api-keys'],
      'gemini' => ['label'=>'Google Gemini','model'=>GEMINI_MODEL,'icon'=>'G','color'=>'#f0fdf4','tc'=>'#10b981','url'=>'https://aistudio.google.com/app/apikey'],
    ];
    foreach ($providers as $p => $info):
      $isActive = !empty($keys[$p]) && $keys[$p]['status'] === 'active';
      $configSet = defined(strtoupper($p).'_API_KEY') && !str_contains(constant(strtoupper($p).'_API_KEY'), 'YOUR_');
    ?>
    <div style="padding:16px;border:1.5px solid var(--border);border-radius:10px;margin-bottom:14px">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
        <div style="width:38px;height:38px;border-radius:8px;background:<?= $info['color'] ?>;display:flex;align-items:center;justify-content:center;font-weight:700;color:<?= $info['tc'] ?>;font-size:14px"><?= $info['icon'] ?></div>
        <div style="flex:1">
          <div style="font-weight:600;font-size:14px"><?= $info['label'] ?></div>
          <div style="font-size:12px;color:var(--text2)"><?= $info['model'] ?></div>
        </div>
        <?php if ($configSet): ?>
          <span class="badge-suc">Config.php ✓</span>
        <?php elseif ($isActive): ?>
          <span class="badge-info">DB Active</span>
        <?php else: ?>
          <span class="badge-gray">Not Set</span>
        <?php endif; ?>
      </div>
      <?php if ($configSet): ?>
        <div style="background:#f0fdf4;border-radius:6px;padding:10px;font-size:12.5px;color:#065f46;margin-bottom:10px"><i class="fa fa-check-circle" style="margin-right:6px"></i>Key loaded from config.php. Override below to use a different key from DB.</div>
      <?php endif; ?>
      <form method="POST">
        <input type="hidden" name="provider" value="<?= $p ?>">
        <div style="display:flex;gap:8px;margin-bottom:10px">
          <input type="password" name="api_key" class="inp" placeholder="Enter new <?= $info['label'] ?> key..." style="flex:1" id="key-<?= $p ?>">
          <button type="button" onclick="toggleVis('key-<?= $p ?>')" class="btn-sec btn-sm-nf"><i class="fa fa-eye"></i></button>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <button type="button" class="btn-sec btn-sm-nf" onclick="testKey('<?= $p ?>')"><i class="fa fa-plug"></i> Test</button>
          <button type="submit" name="save_key" class="btn-primary-nf btn-sm-nf"><i class="fa fa-save"></i> Save Key</button>
          <a href="<?= $info['url'] ?>" target="_blank" style="font-size:12px;color:#3b82f6;margin-left:auto"><i class="fa fa-external-link-alt" style="margin-right:4px"></i>Get Key</a>
        </div>
      </form>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <div class="card-header"><i class="fa fa-newspaper" style="color:#3b82f6;margin-right:8px"></i>News API</div>
  <div class="card-body">
    <?php $naSet = !str_contains(NEWSAPI_KEY,'YOUR_'); ?>
    <?php if ($naSet): ?>
      <div style="background:#f0fdf4;border-radius:6px;padding:10px;font-size:12.5px;color:#065f46;margin-bottom:12px"><i class="fa fa-check-circle" style="margin-right:6px"></i>NewsAPI key set in config.php</div>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="provider" value="newsapi">
      <div class="form-group">
        <label>NewsAPI.org Key</label>
        <div style="display:flex;gap:8px">
          <input type="password" name="api_key" class="inp" id="key-newsapi" placeholder="Get free key at newsapi.org">
          <button type="button" onclick="toggleVis('key-newsapi')" class="btn-sec btn-sm-nf"><i class="fa fa-eye"></i></button>
        </div>
        <div style="font-size:12px;color:var(--text2);margin-top:5px">Free tier: 100 requests/day. <a href="https://newsapi.org" target="_blank" style="color:#3b82f6">newsapi.org</a></div>
      </div>
      <button type="submit" name="save_key" class="btn-primary-nf btn-sm-nf"><i class="fa fa-save"></i> Save Key</button>
    </form>
    <hr style="margin:16px 0;border-color:var(--border)">
    <div style="display:flex;align-items:center;justify-content:space-between">
      <div><div style="font-size:13.5px;font-weight:500">Google News RSS</div><div style="font-size:12px;color:var(--text2)">Free — no key required</div></div>
      <span class="badge-suc">Enabled</span>
    </div>
  </div>
</div>
</div>

<div>
<div class="card mb-4">
  <div class="card-header">Quick Setup Guide</div>
  <div class="card-body">
    <div style="font-size:13.5px;line-height:1.8">
      <div style="margin-bottom:16px"><strong style="color:#e94560">Step 1 — Edit config.php</strong><br>Open <code style="background:#f1f3f7;padding:2px 6px;border-radius:4px;font-size:12px">newsforge/config.php</code> and replace the placeholder values with your real API keys.</div>
      <div style="margin-bottom:16px"><strong style="color:#e94560">Step 2 — Database</strong><br>Create a MySQL database named <code style="background:#f1f3f7;padding:2px 6px;border-radius:4px;font-size:12px">newsforge_db</code> and set credentials in config.php. Tables auto-create on first load.</div>
      <div style="margin-bottom:16px"><strong style="color:#e94560">Step 3 — WordPress</strong><br>Go to <strong>WordPress Sites</strong> and add your sites. For each WP site, create an Application Password: WP Admin → Users → Your Profile → Application Passwords.</div>
      <div><strong style="color:#e94560">Step 4 — Test</strong><br>Use the Test button on each API key to verify connectivity before publishing.</div>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-header">System Info</div>
  <div class="card-body">
    <?php
    $checks = [
      'PHP Version (8.0+)' => version_compare(PHP_VERSION,'8.0','>='),
      'cURL Extension'     => function_exists('curl_init'),
      'OpenSSL Extension'  => function_exists('openssl_encrypt'),
      'MySQL / PDO'        => extension_loaded('pdo_mysql'),
      'Config DB Host'     => DB_HOST !== '',
      'Config DB Name'     => DB_NAME !== '',
      'Upload Directory'   => is_writable(UPLOAD_DIR),
    ];
    foreach ($checks as $label => $ok):
    ?>
      <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:13px">
        <span><?= $label ?></span>
        <span class="<?= $ok?'badge-suc':'badge-err' ?>"><?= $ok?'✓ OK':'✗ Missing' ?></span>
      </div>
    <?php endforeach; ?>
  </div>
</div>
</div>
</div>

<script>
function toggleVis(id){const e=document.getElementById(id);e.type=e.type==='password'?'text':'password'}
async function testKey(provider){
  showToast('Testing '+provider+' connection...','');
  const key=document.getElementById('key-'+provider).value;
  if(!key){showToast('Enter a key to test','error');return;}
  // Simple test: call our generate API with a short test prompt
  const resp=await fetch('api/generate.php',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({engine:provider,title:'Test',content:'Hello',language:'English',style:'summary',extra:'Reply with just: {"seoTitle":"test","metaDescription":"test","body":"<p>ok</p>","tags":"test"}'})
  });
  const d=await resp.json();
  if(d.error)showToast(provider+' Error: '+d.error,'error');
  else showToast(provider+' API connected successfully!','success');
}
</script>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>

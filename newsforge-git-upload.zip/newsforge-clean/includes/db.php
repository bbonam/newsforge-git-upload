<?php
require_once __DIR__ . '/../config.php';

class Database {
    private static $pdo = null;

    private static function createConnection(): PDO {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            // Keep connection alive longer on the PHP side
            PDO::ATTR_TIMEOUT            => 60,
        ]);
        // Tell MySQL to keep this connection open for 3 minutes
        $pdo->exec("SET SESSION wait_timeout=180, interactive_timeout=180");
        return $pdo;
    }

    public static function connect(): PDO {
        if (self::$pdo === null) {
            try {
                self::$pdo = self::createConnection();
            } catch (PDOException $e) {
                die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
            }
        }
        return self::$pdo;
    }

    /**
     * Call this after any long-running external operation (API calls, etc.)
     * to get a guaranteed fresh connection before writing to the DB.
     */
    public static function reconnect(): PDO {
        self::$pdo = null;
        return self::connect();
    }

    public static function query(string $sql, array $params = []): \PDOStatement {
        try {
            $stmt = self::connect()->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            // "MySQL server has gone away" (2006) or "Lost connection" (2013)
            if (in_array($e->errorInfo[1] ?? 0, [2006, 2013])) {
                // Reconnect once and retry
                self::reconnect();
                $stmt = self::connect()->prepare($sql);
                $stmt->execute($params);
                return $stmt;
            }
            throw $e;
        }
    }
}

// ── Install schema if tables missing ─────────────────────────
function install_schema(): void {
    $pdo = Database::connect();
    $pdo->exec("
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        fullname VARCHAR(100) NOT NULL,
        email VARCHAR(150),
        role ENUM('admin','publisher') DEFAULT 'publisher',
        status ENUM('active','inactive') DEFAULT 'active',
        created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_date DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS wordpress_sites (
        id INT AUTO_INCREMENT PRIMARY KEY,
        site_name VARCHAR(150) NOT NULL,
        site_url VARCHAR(255) NOT NULL,
        wp_username VARCHAR(100) NOT NULL,
        wp_password VARCHAR(255) NOT NULL,
        secret_key VARCHAR(255) DEFAULT '',
        default_category VARCHAR(100),
        status ENUM('active','inactive') DEFAULT 'active',
        created_date DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS articles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(500),
        seo_title VARCHAR(500),
        meta_description TEXT,
        original_content LONGTEXT,
        generated_content LONGTEXT,
        image_url VARCHAR(500),
        language VARCHAR(20) DEFAULT 'English',
        ai_engine VARCHAR(30),
        source_url VARCHAR(500),
        source_name VARCHAR(200),
        tags TEXT,
        status ENUM('draft','ready','published') DEFAULT 'draft',
        created_by INT,
        created_date DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS published_posts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        article_id INT,
        site_id INT,
        wp_post_id INT,
        publish_status VARCHAR(50),
        published_date DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS api_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        provider_name VARCHAR(50) UNIQUE NOT NULL,
        api_key TEXT,
        status ENUM('active','inactive') DEFAULT 'inactive',
        updated_date DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS activity_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        username VARCHAR(50),
        action VARCHAR(100),
        description TEXT,
        ip_address VARCHAR(45),
        created_date DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    ");

    // Seed default users
    $check = Database::query("SELECT COUNT(*) as c FROM users")->fetch();
    if ($check['c'] == 0) {
        $adminHash = password_hash('admin123', PASSWORD_BCRYPT);
        $pubHash   = password_hash('publisher123', PASSWORD_BCRYPT);
        Database::query("INSERT INTO users (username,password,fullname,email,role,status) VALUES
            ('admin',?,  'Administrator','admin@newsforge.com',   'admin',     'active'),
            ('publisher1',?,'Publisher One','pub1@newsforge.com','publisher','active')",
            [$adminHash, $pubHash]);

        // Seed sample WP sites
        Database::query("INSERT INTO wordpress_sites (site_name,site_url,wp_username,wp_password,default_category,status) VALUES
            ('TeluguWonders.com','https://teluguwonders.com','twadmin','app_password_here','Regional News','active'),
            ('APNewsDaily.com','https://apnewsdaily.com','apnadmin','app_password_here','AP News','active'),
            ('IndianPoliticalHub.com','https://indianpoliticalhub.com','iphadmin','app_password_here','Politics','active'),
            ('VoterChronicle.com','https://voterchronicle.com','vcadmin','app_password_here','Elections','inactive'),
            ('HappyThePet.com','https://happythepet.com','petadmin','app_password_here','Pets','active')");

        // Seed API settings
        Database::query("INSERT INTO api_settings (provider_name,api_key,status) VALUES
            ('claude','',  'inactive'),
            ('openai','',  'inactive'),
            ('gemini','',  'inactive'),
            ('newsapi','', 'inactive')");
    }

    // Always run column migrations (safe to call repeatedly)
    maybe_add_secret_key_column();
}

// ── Run once: add secret_key column if missing ────────────────
// Uses SHOW COLUMNS instead of IF NOT EXISTS — works on all MySQL versions
function maybe_add_secret_key_column(): void {
    try {
        $cols = Database::connect()->query("SHOW COLUMNS FROM wordpress_sites LIKE 'secret_key'")->fetchAll();
        if (empty($cols)) {
            Database::connect()->exec(
                "ALTER TABLE wordpress_sites ADD COLUMN secret_key VARCHAR(255) NOT NULL DEFAULT '' AFTER wp_password"
            );
        }
    } catch (PDOException $e) {
        // Table may not exist yet — install_schema() will create it with the column included
    }
}

<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/db.php';

function session_start_safe(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict']);
        session_start();
    }
}

function is_logged_in(): bool {
    session_start_safe();
    if (empty($_SESSION['user_id'])) return false;
    if (time() - ($_SESSION['last_active'] ?? 0) > SESSION_TIMEOUT) {
        session_destroy();
        return false;
    }
    $_SESSION['last_active'] = time();
    return true;
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: ' . APP_URL . '/index.php');
        exit;
    }
}

function require_admin(): void {
    require_login();
    if ($_SESSION['role'] !== 'admin') {
        http_response_code(403);
        die('Access denied');
    }
}

function current_user(): array {
    return [
        'id'       => $_SESSION['user_id']   ?? 0,
        'username' => $_SESSION['username']  ?? '',
        'fullname' => $_SESSION['fullname']  ?? '',
        'role'     => $_SESSION['role']      ?? 'publisher',
    ];
}

function do_login(string $username, string $password): bool {
    $row = Database::query(
        "SELECT * FROM users WHERE username=? AND status='active'", [$username]
    )->fetch();
    if ($row && password_verify($password, $row['password'])) {
        session_start_safe();
        session_regenerate_id(true);
        $_SESSION['user_id']   = $row['id'];
        $_SESSION['username']  = $row['username'];
        $_SESSION['fullname']  = $row['fullname'];
        $_SESSION['role']      = $row['role'];
        $_SESSION['last_active'] = time();
        log_activity('Login', 'User logged in');
        return true;
    }
    return false;
}

function do_logout(): void {
    session_start_safe();
    log_activity('Logout', 'User logged out');
    session_destroy();
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

function log_activity(string $action, string $description): void {
    session_start_safe();
    $uid  = $_SESSION['user_id']  ?? 0;
    $uname= $_SESSION['username'] ?? 'system';
    $ip   = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    Database::query(
        "INSERT INTO activity_logs (user_id,username,action,description,ip_address) VALUES (?,?,?,?,?)",
        [$uid, $uname, $action, $description, $ip]
    );
}

function csrf_token(): string {
    session_start_safe();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        die('CSRF verification failed');
    }
}

function encrypt_key(string $data): string {
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . $encrypted);
}

function decrypt_key(string $data): string {
    $raw = base64_decode($data);
    $iv  = substr($raw, 0, 16);
    $enc = substr($raw, 16);
    return openssl_decrypt($enc, 'aes-256-cbc', ENCRYPTION_KEY, 0, $iv);
}

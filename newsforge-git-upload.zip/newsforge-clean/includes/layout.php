<?php
// includes/layout.php — shared header + sidebar
// Usage: include at top of each page AFTER require_login()
// Expects $pageTitle and $activePage to be set
require_once __DIR__ . '/../config.php';
$user = current_user();
$isAdmin = $user['role'] === 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle ?? 'Dashboard') ?> — <?= APP_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root{--primary:#1a1a2e;--accent:#e94560;--sidebar-w:240px;--topbar-h:60px;--surface2:#f8f9fb;--border:#e5e7eb;--text2:#6b7280;--radius:10px;--shadow:0 2px 12px rgba(0,0,0,.08)}
*{box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;background:var(--surface2);color:#1a1a2e;margin:0}
.sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;background:var(--primary);z-index:200;display:flex;flex-direction:column;overflow:hidden}
.brand{padding:18px 20px 12px;border-bottom:1px solid rgba(255,255,255,.08);font-family:'Playfair Display',serif;color:white;font-size:20px}
.brand span{color:var(--accent)}
.brand-sub{font-size:11px;color:rgba(255,255,255,.35);font-family:'DM Sans',sans-serif;margin-top:2px}
.nav-scroll{overflow-y:auto;flex:1}
.nav-section{padding:14px 0 4px;font-size:10px;color:rgba(255,255,255,.3);letter-spacing:1px;text-transform:uppercase;padding-left:20px}
.nav-item{display:flex;align-items:center;gap:10px;padding:10px 20px;color:rgba(255,255,255,.6);font-size:13.5px;cursor:pointer;transition:.15s;border-left:3px solid transparent;text-decoration:none}
.nav-item:hover{color:white;background:rgba(255,255,255,.06)}
.nav-item.active{color:white;background:rgba(233,69,96,.15);border-left-color:var(--accent)}
.nav-item i{width:18px;font-size:14px}
.sidebar-user{margin-top:auto;padding:14px 20px;border-top:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:10px}
.u-avatar{width:34px;height:34px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;color:white;font-weight:600;font-size:13px;flex-shrink:0}
.u-name{font-size:13px;color:white;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.u-role{font-size:11px;color:rgba(255,255,255,.4)}
.topbar{position:fixed;top:0;left:var(--sidebar-w);right:0;height:var(--topbar-h);background:white;border-bottom:1px solid var(--border);z-index:100;display:flex;align-items:center;padding:0 24px;gap:16px}
.page-title{font-size:15px;font-weight:600;flex:1}
.main{margin-left:var(--sidebar-w);margin-top:var(--topbar-h);padding:26px;min-height:calc(100vh - var(--topbar-h))}
/* COMMON COMPONENTS */
.card{background:white;border-radius:var(--radius);border:1px solid var(--border);box-shadow:var(--shadow)}
.card-header{padding:15px 20px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px;display:flex;align-items:center;justify-content:space-between}
.card-body{padding:20px}
.btn-primary-nf{background:var(--accent);color:white;border:none;border-radius:8px;padding:9px 18px;font-size:13.5px;font-weight:500;cursor:pointer;display:inline-flex;align-items:center;gap:7px;text-decoration:none;transition:.15s}
.btn-primary-nf:hover{background:#d63651;color:white}
.btn-sec{background:#f8f9fb;color:#1a1a2e;border:1px solid var(--border);border-radius:8px;padding:9px 18px;font-size:13.5px;font-weight:500;cursor:pointer;display:inline-flex;align-items:center;gap:7px;text-decoration:none;transition:.15s}
.btn-sec:hover{background:#f1f3f7}
.btn-sm-nf{padding:6px 12px!important;font-size:12.5px!important;border-radius:6px!important}
.inp{width:100%;border:1.5px solid var(--border);border-radius:8px;padding:9px 13px;font-size:13.5px;outline:none;font-family:inherit;transition:.2s;background:white}
.inp:focus{border-color:var(--accent)}
.badge-suc{background:#d1fae5;color:#065f46;font-size:11px;padding:3px 9px;border-radius:20px;font-weight:500}
.badge-warn{background:#fef3c7;color:#92400e;font-size:11px;padding:3px 9px;border-radius:20px;font-weight:500}
.badge-info{background:#dbeafe;color:#1e40af;font-size:11px;padding:3px 9px;border-radius:20px;font-weight:500}
.badge-gray{background:#f1f3f7;color:var(--text2);font-size:11px;padding:3px 9px;border-radius:20px;font-weight:500}
.badge-err{background:#fee2e2;color:#991b1b;font-size:11px;padding:3px 9px;border-radius:20px;font-weight:500}
.data-table{width:100%;border-collapse:collapse;font-size:13.5px}
.data-table th{padding:10px 14px;background:var(--surface2);color:var(--text2);font-weight:500;font-size:12px;text-align:left;border-bottom:1px solid var(--border)}
.data-table td{padding:12px 14px;border-bottom:1px solid var(--border)}
.data-table tr:last-child td{border-bottom:none}
.data-table tr:hover td{background:#fafafa}
.form-group{margin-bottom:16px}
.form-group label{font-size:13px;font-weight:500;color:var(--text2);margin-bottom:6px;display:block}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
.toast-wrap{position:fixed;bottom:24px;right:24px;z-index:9999}
.toast-item{background:#1a1a2e;color:white;padding:12px 18px;border-radius:10px;font-size:13.5px;display:flex;align-items:center;gap:10px;margin-top:8px;box-shadow:0 8px 24px rgba(0,0,0,.2);animation:slideIn .3s}
.toast-suc{background:#065f46}.toast-err{background:#991b1b}
@keyframes slideIn{from{transform:translateX(120%);opacity:0}to{transform:translateX(0);opacity:1}}
#modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1000;align-items:center;justify-content:center}
#modal-overlay.show{display:flex}
.modal-box{background:white;border-radius:14px;padding:28px;width:520px;max-width:96vw;max-height:90vh;overflow-y:auto;position:relative}
.modal-close{position:absolute;top:14px;right:14px;width:28px;height:28px;border-radius:6px;background:#f1f3f7;border:none;cursor:pointer;font-size:13px;color:var(--text2)}
</style>
</head>
<body>

<div class="sidebar">
  <div class="brand">News<span>Forge</span> AI<div class="brand-sub"><?= $isAdmin ? 'Administrator' : 'Publisher' ?></div></div>
  <div class="nav-scroll">
    <div class="nav-section">Main</div>
    <a href="dashboard.php" class="nav-item <?= $activePage==='dashboard'?'active':'' ?>"><i class="fa fa-th-large"></i> Dashboard</a>
    <a href="news-search.php" class="nav-item <?= $activePage==='news-search'?'active':'' ?>"><i class="fa fa-search"></i> Search News</a>
    <a href="ai-generate.php" class="nav-item <?= $activePage==='ai-generate'?'active':'' ?>"><i class="fa fa-magic"></i> AI Generate</a>
    <a href="editor.php" class="nav-item <?= $activePage==='editor'?'active':'' ?>"><i class="fa fa-edit"></i> Proof Reading</a>
    <a href="publish.php" class="nav-item <?= $activePage==='publish'?'active':'' ?>"><i class="fa fa-paper-plane"></i> Publish</a>
    <?php if ($isAdmin): ?>
    <div class="nav-section">Management</div>
    <a href="wp-sites.php" class="nav-item <?= $activePage==='wp-sites'?'active':'' ?>"><i class="fa fa-globe"></i> WordPress Sites</a>
    <a href="publishers.php" class="nav-item <?= $activePage==='publishers'?'active':'' ?>"><i class="fa fa-users"></i> Publishers</a>
    <a href="api-settings.php" class="nav-item <?= $activePage==='api-settings'?'active':'' ?>"><i class="fa fa-key"></i> API Settings</a>
    <?php endif; ?>
    <div class="nav-section">Reports</div>
    <a href="activity-logs.php" class="nav-item <?= $activePage==='activity-logs'?'active':'' ?>"><i class="fa fa-list-alt"></i> Activity Logs</a>
    <div class="nav-section">Account</div>
    <a href="profile.php" class="nav-item <?= $activePage==='profile'?'active':'' ?>"><i class="fa fa-user"></i> My Profile</a>
    <a href="change-password.php" class="nav-item <?= $activePage==='change-password'?'active':'' ?>"><i class="fa fa-lock"></i> Change Password</a>
  </div>
  <div class="sidebar-user">
    <div class="u-avatar"><?= strtoupper(substr($user['fullname'],0,1)) ?></div>
    <div style="flex:1;overflow:hidden"><div class="u-name"><?= htmlspecialchars($user['fullname']) ?></div><div class="u-role"><?= htmlspecialchars($user['username']) ?></div></div>
    <a href="logout.php" title="Logout" style="color:rgba(255,255,255,.4);font-size:14px"><i class="fa fa-sign-out-alt"></i></a>
  </div>
</div>

<div class="topbar">
  <div class="page-title"><?= htmlspecialchars($pageTitle ?? 'Dashboard') ?></div>
  <div style="display:flex;align-items:center;gap:10px">
    <?php if($isAdmin): ?><a href="api-settings.php" style="color:var(--text2);font-size:14px"><i class="fa fa-cog"></i></a><?php endif; ?>
    <span style="font-size:13px;color:var(--text2)"><?= htmlspecialchars($user['username']) ?></span>
    <div class="u-avatar" style="width:30px;height:30px;font-size:11px"><?= strtoupper(substr($user['fullname'],0,1)) ?></div>
  </div>
</div>

<div class="main" id="main-content">

<div id="modal-overlay"><div class="modal-box" id="modal-content"></div></div>
<div class="toast-wrap" id="toast-wrap"></div>

<script>
function showToast(msg,type=''){
  const w=document.getElementById('toast-wrap');
  const d=document.createElement('div');
  d.className='toast-item '+(type==='success'?'toast-suc':type==='error'?'toast-err':'');
  d.innerHTML=`<i class="fa ${type==='success'?'fa-check-circle':type==='error'?'fa-times-circle':'fa-info-circle'}"></i> ${msg}`;
  w.appendChild(d);
  setTimeout(()=>{d.style.opacity='0';d.style.transition='.3s';setTimeout(()=>d.remove(),350)},3500);
}
function showModal(html){
  document.getElementById('modal-content').innerHTML=html+'<button class="modal-close" onclick="closeModal()"><i class="fa fa-times"></i></button>';
  document.getElementById('modal-overlay').classList.add('show');
}
function closeModal(){document.getElementById('modal-overlay').classList.remove('show')}
document.getElementById('modal-overlay').addEventListener('click',e=>{if(e.target.id==='modal-overlay')closeModal()});
async function apiPost(url,data){
  const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  return r.json();
}
async function apiGet(url){const r=await fetch(url);return r.json();}
</script>

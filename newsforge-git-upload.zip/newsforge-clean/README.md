# NewsForge AI — Multi-WordPress AI Publishing Platform

A PHP web application for discovering news, rewriting content with AI (Claude, OpenAI, Gemini), and publishing to multiple WordPress sites from one dashboard.

## Features

- 🔍 **News Search** — NewsAPI.org (primary) + Google News RSS fallback
- 🤖 **AI Generation** — Claude, OpenAI GPT-4o, Google Gemini
- 🖼️ **Auto Images** — DALL-E 3 (OpenAI), Unsplash (Claude/Gemini), OG scraping
- ✏️ **Proof Reading Editor** — Rich text editor with metadata management
- 🚀 **Multi-site Publishing** — Publish to multiple WordPress sites simultaneously
- 🔐 **Role-based Access** — Administrator and Publisher roles
- 📊 **Activity Logs** — Full audit trail of all actions

## Tech Stack

- **Backend:** PHP 8.x, MySQL 8.x
- **Frontend:** Bootstrap 5, vanilla JS
- **AI:** Anthropic Claude, OpenAI, Google Gemini
- **WordPress:** Custom plugin (NewsForge Publisher) via REST API

## Requirements

- PHP 8.0+ with cURL, GD, OpenSSL, PDO/MySQL
- MySQL 8.x
- Web server: Apache or Nginx (LiteSpeed supported via NewsForge plugin)

## Installation

### 1. Upload files
Upload the `newsforge/` folder to your web server's public directory.

### 2. Create database
```sql
CREATE DATABASE newsforge_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 3. Configure
```bash
cp config.sample.php config.php
```
Edit `config.php` and fill in all values (see Configuration section below).

### 4. Set permissions
```bash
chmod 755 newsforge/
chmod 777 newsforge/uploads/images/
```

### 5. Visit in browser
Navigate to `https://yourdomain.com/newsforge`  
Tables are auto-created on first load.

**Default credentials:**
- Admin: `admin` / `admin123`
- Publisher: `publisher1` / `publisher123`

> ⚠️ Change default passwords immediately after first login.

---

## Configuration (`config.php`)

| Setting | Where to get it | Required |
|---|---|---|
| `DB_HOST` / `DB_NAME` / `DB_USER` / `DB_PASS` | Your MySQL server | ✅ Yes |
| `ANTHROPIC_API_KEY` | [console.anthropic.com](https://console.anthropic.com/) | ✅ For Claude |
| `OPENAI_API_KEY` | [platform.openai.com/api-keys](https://platform.openai.com/api-keys) | For OpenAI + DALL-E 3 |
| `GEMINI_API_KEY` | [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey) | For Gemini |
| `NEWSAPI_KEY` | [newsapi.org](https://newsapi.org/) — free 100 req/day | Recommended |
| `UNSPLASH_ACCESS_KEY` | [unsplash.com/developers](https://unsplash.com/developers) — free | For Unsplash images |
| `APP_URL` | Your domain | ✅ Yes |
| `SECRET_KEY` | Generate: `openssl rand -hex 32` | ✅ Yes |
| `ENCRYPTION_KEY` | Generate: `openssl rand -hex 16` (must be 32 chars) | ✅ Yes |

---

## WordPress Site Setup

Each WordPress site needs the **NewsForge Publisher plugin** installed:

1. Upload `newsforge-publisher-plugin/newsforge-publisher.php` to WordPress
2. Activate the plugin
3. Go to **WP Admin → Settings → NewsForge Publisher**
4. Copy the secret key
5. Paste into **NewsForge → WordPress Sites → Edit → Secret Key**

> The plugin bypasses LiteSpeed/Hostinger Authorization header stripping — no Application Passwords needed.

---

## File Structure

```
newsforge/
├── config.php              ← Master config (gitignored — use config.sample.php)
├── config.sample.php       ← Template — copy to config.php
├── index.php               ← Login page
├── dashboard.php
├── news-search.php
├── ai-generate.php
├── editor.php
├── publish.php
├── wp-sites.php
├── publishers.php
├── api-settings.php
├── activity-logs.php
├── profile.php
├── change-password.php
├── logout.php
├── api/
│   ├── generate.php        ← AI content generation (Claude/OpenAI/Gemini)
│   ├── news.php            ← News fetching (NewsAPI + RSS)
│   ├── publish.php         ← WordPress publishing
│   ├── sites.php           ← WordPress sites CRUD
│   ├── image.php           ← Branded SVG image generator
│   └── editor_save.php     ← Save editor content to DB
├── includes/
│   ├── auth.php            ← Login, session, CSRF
│   ├── db.php              ← Database connection + migrations
│   ├── layout.php          ← Sidebar + topbar (shared header)
│   └── layout_footer.php
└── uploads/
    └── images/             ← Downloaded/generated images (gitignored)
```

---

## Known Issues & Fixes Applied

| Issue | Fix |
|---|---|
| MySQL "server has gone away" (2006) | `Database::reconnect()` before DB writes after long API calls |
| Hostinger LiteSpeed strips Authorization header | NewsForge Publisher plugin uses `X-NewsForge-Key` header |
| WordPress 401 on Application Passwords | Plugin-based auth replaces Application Passwords entirely |
| Duplicate article publishing | sessionStorage cleared after successful publish |
| Featured image not uploading | Image downloaded to server, sent as stable local URL to WP |
| `php://input` read twice in sites.php | Single read at top of file |
| `secret_key` column missing | `SHOW COLUMNS` migration on page load |

---

## WordPress Plugin

Located in `newsforge-publisher-plugin/newsforge-publisher.php`

Registers a secure REST endpoint at:
```
https://yourwpsite.com/wp-json/newsforge/v1/publish
```

Authenticated via `X-NewsForge-Key` header (not Authorization). Handles:
- Post creation with categories and tags
- Featured image upload via `download_url()`
- Yoast SEO and RankMath meta fields
- Scheduled publishing

---

## License

Private / Proprietary — All rights reserved.

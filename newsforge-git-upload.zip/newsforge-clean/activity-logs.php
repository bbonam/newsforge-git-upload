<?php
// activity-logs.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$pageTitle='Activity Logs';$activePage='activity-logs';
$user=current_user();
$filterUser=$_GET['user']??'';
$filterAction=$_GET['action_type']??'';
$sql="SELECT * FROM activity_logs";$params=[];$where=[];
if(!empty($filterUser)){$where[]="username=?";$params[]=$filterUser;}
if(!empty($filterAction)){$where[]="action LIKE ?";$params[]="%$filterAction%";}
if($user['role']!=='admin'){$where[]="username=?";$params[]=$user['username'];}
if($where)$sql.=" WHERE ".implode(' AND ',$where);
$sql.=" ORDER BY id DESC LIMIT 200";
$logs=Database::query($sql,$params)->fetchAll();
$users=Database::query("SELECT DISTINCT username FROM activity_logs ORDER BY username")->fetchAll();
include __DIR__.'/includes/layout.php';
?>
<div class="card mb-3">
  <div class="card-body">
    <form style="display:flex;gap:12px;flex-wrap:wrap">
      <?php if($user['role']==='admin'):?>
      <div style="flex:1;min-width:150px"><label style="font-size:12px;color:var(--text2);display:block;margin-bottom:4px">User</label>
        <select name="user" class="inp"><option value="">All Users</option><?php foreach($users as $u):?><option value="<?=htmlspecialchars($u['username'])?>" <?=$filterUser===$u['username']?'selected':''?>><?=htmlspecialchars($u['username'])?></option><?php endforeach;?></select></div>
      <?php endif;?>
      <div style="flex:1;min-width:150px"><label style="font-size:12px;color:var(--text2);display:block;margin-bottom:4px">Action</label>
        <select name="action_type" class="inp"><option value="">All Actions</option><option value="Login">Login</option><option value="Logout">Logout</option><option value="Search">News Search</option><option value="Generate">AI Generate</option><option value="Publish">Publish</option></select></div>
      <div style="display:flex;align-items:flex-end;gap:8px">
        <button type="submit" class="btn-sec btn-sm-nf"><i class="fa fa-filter"></i> Filter</button>
        <a href="activity-logs.php" class="btn-sec btn-sm-nf"><i class="fa fa-times"></i> Clear</a>
      </div>
    </form>
  </div>
</div>
<div class="card">
  <div class="card-header">Activity Logs <span class="badge-info" style="margin-left:8px"><?=count($logs)?> entries</span></div>
  <div class="card-body" style="padding:0">
    <table class="data-table">
      <thead><tr><th>#</th><th>User</th><th>Action</th><th>Description</th><th>IP</th><th>Time</th></tr></thead>
      <tbody>
      <?php foreach($logs as $l):
        $badgeClass=match(true){
          str_contains($l['action'],'Login')||str_contains($l['action'],'Logout')=>'badge-gray',
          str_contains($l['action'],'Publish')||(str_contains($l['action'],'Published'))==>'badge-suc',
          str_contains($l['action'],'Fail')==>'badge-err',
          str_contains($l['action'],'Generate')==>'badge-info',
          default=>'badge-warn'
        };
      ?>
        <tr>
          <td style="font-size:12px;color:#9ca3af"><?=$l['id']?></td>
          <td><span class="badge-gray"><?=htmlspecialchars($l['username'])?></span></td>
          <td><span class="<?=$badgeClass?>"><?=htmlspecialchars($l['action'])?></span></td>
          <td style="font-size:13px"><?=htmlspecialchars($l['description'])?></td>
          <td style="font-size:12px;color:#9ca3af"><?=htmlspecialchars($l['ip_address']??'')?></td>
          <td style="font-size:12px;color:#9ca3af;white-space:nowrap"><?=date('d M H:i',strtotime($l['created_date']))?></td>
        </tr>
      <?php endforeach;?>
      <?php if(empty($logs)):?><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text2)">No logs found</td></tr><?php endif;?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__.'/includes/layout_footer.php'; ?>

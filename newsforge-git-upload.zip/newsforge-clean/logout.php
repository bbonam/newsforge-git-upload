<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
do_logout();

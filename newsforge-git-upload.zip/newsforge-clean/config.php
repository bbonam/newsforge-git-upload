<?php
// ============================================================
//  NewsForge AI — Master Configuration File
//  Edit ONLY this file to configure all API keys and settings
// ============================================================

// ── DATABASE ─────────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_NAME', 'newsforge_db');
define('DB_USER', 'root');          // Your MySQL username
define('DB_PASS', '');              // Your MySQL password
define('DB_CHARSET', 'utf8mb4');

// ── AI API KEYS ───────────────────────────────────────────────
// Claude (Anthropic) — https://console.anthropic.com/
define('ANTHROPIC_API_KEY', 'YOUR_ANTHROPIC_API_KEY_HERE');
define('ANTHROPIC_MODEL', 'claude-sonnet-4-20250514');

// OpenAI — https://platform.openai.com/api-keys
// Used for: GPT-4o text generation + DALL-E 3 image generation
define('OPENAI_API_KEY', 'YOUR_OPENAI_API_KEY_HERE');
define('OPENAI_MODEL', 'gpt-4o');

// Google Gemini — https://aistudio.google.com/app/apikey
define('GEMINI_API_KEY', 'YOUR_GEMINI_API_KEY_HERE');
define('GEMINI_MODEL', 'gemini-1.5-pro');

// ── IMAGE APIs ────────────────────────────────────────────────
// Unsplash — https://unsplash.com/developers (free: 50 req/hour)
// Used as fallback image when Claude or Gemini is selected
define('UNSPLASH_ACCESS_KEY', 'YOUR_UNSPLASH_ACCESS_KEY_HERE');

// ── NEWS SOURCES ──────────────────────────────────────────────
// NewsAPI.org — https://newsapi.org/ (free tier: 100 req/day)
define('NEWSAPI_KEY', 'YOUR_NEWSAPI_KEY_HERE');

// Google News RSS (free — no key required)
define('GOOGLE_NEWS_RSS_ENABLED', true);

// ── SECURITY ──────────────────────────────────────────────────
define('SECRET_KEY', 'change-this-to-a-random-64-char-string-for-production');
define('SESSION_TIMEOUT', 1800); // 30 minutes in seconds

// ── APPLICATION ───────────────────────────────────────────────
define('APP_NAME', 'NewsForge AI');
define('APP_URL', 'http://localhost/newsforge'); // Change to your domain
define('APP_VERSION', '1.0.0');
define('UPLOAD_DIR', __DIR__ . '/uploads/images/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('NEWS_RESULTS_LIMIT', 6);
define('DEFAULT_LANGUAGE', 'English');

// ── ENCRYPTION (for DB-stored keys) ──────────────────────────
define('ENCRYPTION_KEY', 'change-this-32-char-key-for-prod!!'); // Must be 32 chars

// ── TIMEZONE ─────────────────────────────────────────────────
date_default_timezone_set('Asia/Kolkata');

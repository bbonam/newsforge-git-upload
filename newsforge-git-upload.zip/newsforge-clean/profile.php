<?php
// profile.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$cu=current_user();
$row=Database::query("SELECT * FROM users WHERE id=?",[$cu['id']])->fetch();
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['update_profile'])){
    $fn=trim($_POST['fullname']??'');$em=trim($_POST['email']??'');
    if($fn){Database::query("UPDATE users SET fullname=?,email=? WHERE id=?",[$fn,$em,$cu['id']]);$_SESSION['fullname']=$fn;log_activity('Profile Update','Updated profile');$msg='Profile updated!';}
}
$pageTitle='My Profile';$activePage='profile';
$stats=['total'=>Database::query("SELECT COUNT(*) c FROM articles WHERE created_by=?",[$cu['id']])->fetch()['c'],'published'=>Database::query("SELECT COUNT(*) c FROM published_posts pp JOIN articles a ON pp.article_id=a.id WHERE a.created_by=?",[$cu['id']])->fetch()['c']];
include __DIR__.'/includes/layout.php';
?>
<?php if(isset($msg)):?><div style="background:#d1fae5;color:#065f46;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:13.5px"><i class="fa fa-check-circle" style="margin-right:6px"></i><?=htmlspecialchars($msg)?></div><?php endif;?>
<div class="grid-2">
<div class="card">
  <div class="card-header">My Profile</div>
  <div class="card-body">
    <div style="text-align:center;margin-bottom:24px">
      <div style="width:70px;height:70px;border-radius:50%;background:#e94560;display:flex;align-items:center;justify-content:center;color:white;font-size:26px;font-weight:700;margin:0 auto 10px"><?=strtoupper(substr($row['fullname'],0,1))?></div>
      <div style="font-weight:700;font-size:18px"><?=htmlspecialchars($row['fullname'])?></div>
      <div style="color:var(--text2);font-size:13px"><?=ucfirst($row['role'])?></div>
    </div>
    <form method="POST">
      <div class="form-group"><label>Full Name</label><input type="text" name="fullname" class="inp" value="<?=htmlspecialchars($row['fullname'])?>"></div>
      <div class="form-group"><label>Email</label><input type="email" name="email" class="inp" value="<?=htmlspecialchars($row['email']??'')?>"></div>
      <div class="form-group"><label>Username</label><input type="text" class="inp" value="<?=htmlspecialchars($row['username'])?>" disabled style="background:#f8f9fb"></div>
      <div class="form-group mb-0"><label>Role</label><input type="text" class="inp" value="<?=ucfirst($row['role'])?>" disabled style="background:#f8f9fb"></div>
      <div style="margin-top:16px"><button type="submit" name="update_profile" class="btn-primary-nf"><i class="fa fa-save"></i> Update Profile</button></div>
    </form>
  </div>
</div>
<div>
  <div class="card mb-4">
    <div class="card-header">My Stats</div>
    <div class="card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div style="background:#f8f9fb;border-radius:8px;padding:16px;text-align:center"><div style="font-size:24px;font-weight:700;color:#e94560"><?=$stats['total']?></div><div style="font-size:12px;color:var(--text2)">Articles Generated</div></div>
        <div style="background:#f8f9fb;border-radius:8px;padding:16px;text-align:center"><div style="font-size:24px;font-weight:700;color:#10b981"><?=$stats['published']?></div><div style="font-size:12px;color:var(--text2)">Published</div></div>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header">Account Info</div>
    <div class="card-body">
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:13.5px"><span style="color:var(--text2)">Member Since</span><span><?=date('d M Y',strtotime($row['created_date']))?></span></div>
      <div style="display:flex;justify-content:space-between;padding:8px 0;font-size:13.5px"><span style="color:var(--text2)">Account Status</span><span class="badge-suc"><?=ucfirst($row['status'])?></span></div>
    </div>
  </div>
</div>
</div>
<?php require __DIR__.'/includes/layout_footer.php'; ?>

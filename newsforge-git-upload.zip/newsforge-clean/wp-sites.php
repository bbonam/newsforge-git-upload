<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_admin();

// Ensure secret_key column exists — safe on all MySQL versions
try {
    $ck = Database::connect()->query("SHOW COLUMNS FROM wordpress_sites LIKE 'secret_key'")->fetchAll();
    if (empty($ck)) {
        Database::connect()->exec(
            "ALTER TABLE wordpress_sites ADD COLUMN secret_key VARCHAR(255) NOT NULL DEFAULT '' AFTER wp_password"
        );
    }
} catch (PDOException $e) { /* table may not exist yet — install_schema handles it */ }

$pageTitle  = 'WordPress Sites';
$activePage = 'wp-sites';
$sites = Database::query("SELECT * FROM wordpress_sites ORDER BY id")->fetchAll();
include __DIR__ . '/includes/layout.php';
?>

<style>
.site-form{background:white;border:1px solid var(--border);border-radius:var(--radius);padding:24px;margin-bottom:20px;display:none}
.site-form.open{display:block}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.inp-wrap{position:relative;display:flex;gap:6px}
.inp-wrap .inp{flex:1}
.key-badge{display:inline-flex;align-items:center;gap:4px;background:#d1fae5;color:#065f46;font-size:11px;padding:2px 8px;border-radius:10px;font-weight:500}
.method-tag{font-size:11px;padding:2px 8px;border-radius:10px;font-weight:500}
.tag-plugin{background:#d1fae5;color:#065f46}
.tag-apppass{background:#dbeafe;color:#1e40af}
.tag-none{background:#fee2e2;color:#991b1b}
</style>

<!-- ── ADD / EDIT FORM (shown/hidden inline) ──────────────────── -->
<div class="site-form" id="site-form">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
    <div style="font-size:17px;font-weight:700" id="form-title">
      <i class="fa fa-plus" style="color:#e94560;margin-right:8px"></i>Add WordPress Site
    </div>
    <button class="btn-sec btn-sm-nf" onclick="hideForm()"><i class="fa fa-times"></i> Cancel</button>
  </div>

  <input type="hidden" id="f-id" value="">

  <div class="form-row" style="margin-bottom:16px">
    <div class="form-group mb-0">
      <label>Site Name <span style="color:#ef4444">*</span></label>
      <input type="text" class="inp" id="f-name" placeholder="e.g. AP News Daily">
    </div>
    <div class="form-group mb-0">
      <label>Site URL <span style="color:#ef4444">*</span></label>
      <input type="url" class="inp" id="f-url" placeholder="https://apnewsdaily.com">
      <div style="font-size:11px;color:#9ca3af;margin-top:3px">Root domain only — no /wp-admin, no trailing slash</div>
    </div>
  </div>

  <!-- NewsForge Plugin Key — shown prominently as the recommended method -->
  <div style="border:2px solid #10b981;border-radius:10px;padding:16px;margin-bottom:16px;background:#f0fdf4">
    <div style="font-size:14px;font-weight:600;color:#065f46;margin-bottom:4px">
      <i class="fa fa-plug" style="margin-right:6px"></i>
      NewsForge Publisher Plugin Key
      <span class="key-badge" style="margin-left:8px">Recommended</span>
    </div>
    <div style="font-size:12px;color:#6b7280;margin-bottom:10px">
      Install the <strong>NewsForge Publisher</strong> plugin on your WordPress site, then paste the secret key below.
      This method works on all hosts including Hostinger — no Application Password needed.
    </div>
    <div class="inp-wrap">
      <input type="text" class="inp" id="f-secret"
             placeholder="Paste key from WP Admin → Settings → NewsForge Publisher"
             autocomplete="off">
      <button type="button" class="btn-sec btn-sm-nf" onclick="testPlugin()" id="test-plugin-btn"
              title="Test plugin connection">
        <i class="fa fa-plug"></i> Test
      </button>
    </div>
    <div id="plugin-test-result" style="margin-top:8px;font-size:13px"></div>
  </div>

  <!-- Application Password — fallback -->
  <div style="border:1px solid var(--border);border-radius:10px;padding:16px;margin-bottom:16px">
    <div style="font-size:13.5px;font-weight:600;margin-bottom:4px;color:var(--text)">
      <i class="fa fa-key" style="color:#3b82f6;margin-right:6px"></i>
      Application Password
      <span style="font-size:11px;color:#6b7280;font-weight:400;margin-left:6px">(fallback if no plugin key)</span>
    </div>
    <div style="font-size:12px;color:#6b7280;margin-bottom:10px">
      WP Admin → Users → Your Profile → Application Passwords → Add New
    </div>
    <div class="form-row">
      <div class="form-group mb-0">
        <label style="font-size:12px">WP Username</label>
        <input type="text" class="inp" id="f-user" placeholder="WordPress login username" autocomplete="off">
      </div>
      <div class="form-group mb-0">
        <label style="font-size:12px">Application Password</label>
        <div class="inp-wrap">
          <input type="password" class="inp" id="f-pass"
                 placeholder="Leave blank to keep existing" autocomplete="new-password">
          <button type="button" class="btn-sec btn-sm-nf" onclick="togglePassVis('f-pass')">
            <i class="fa fa-eye"></i>
          </button>
        </div>
      </div>
    </div>
    <div style="margin-top:10px">
      <button type="button" class="btn-sec btn-sm-nf" onclick="testAppPass()">
        <i class="fa fa-plug"></i> Test App Password
      </button>
      <span id="apppass-test-result" style="margin-left:10px;font-size:13px"></span>
    </div>
  </div>

  <div class="form-row" style="margin-bottom:16px">
    <div class="form-group mb-0">
      <label>Default Category</label>
      <input type="text" class="inp" id="f-cat" placeholder="e.g. AP News, Regional, Politics">
    </div>
    <div class="form-group mb-0">
      <label>Status</label>
      <select class="inp" id="f-status">
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
      </select>
    </div>
  </div>

  <div id="form-result" style="margin-bottom:12px;font-size:13px"></div>

  <div style="display:flex;gap:10px">
    <button class="btn-sec" onclick="hideForm()"><i class="fa fa-times"></i> Cancel</button>
    <button class="btn-primary-nf" onclick="saveSite()" id="save-btn" style="margin-left:auto">
      <i class="fa fa-save"></i> Save Site
    </button>
  </div>
</div>

<!-- ── SITES TABLE ─────────────────────────────────────────────── -->
<div style="display:flex;justify-content:flex-end;margin-bottom:16px">
  <button class="btn-primary-nf" onclick="showAddForm()">
    <i class="fa fa-plus"></i> Add WordPress Site
  </button>
</div>

<div class="card">
  <div class="card-header">
    WordPress Sites (<?= count($sites) ?>)
  </div>
  <div class="card-body" style="padding:0">
    <?php if (empty($sites)): ?>
      <div style="text-align:center;padding:50px;color:var(--text2)">
        <i class="fa fa-globe" style="font-size:36px;display:block;margin-bottom:12px;color:#d1d5db"></i>
        <div style="font-weight:600;margin-bottom:8px">No sites added yet</div>
        <button class="btn-primary-nf btn-sm-nf" onclick="showAddForm()"><i class="fa fa-plus"></i> Add First Site</button>
      </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr>
          <th>Site Name</th>
          <th>URL</th>
          <th>Auth Method</th>
          <th>Category</th>
          <th>Status</th>
          <th style="width:150px">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($sites as $s):
        $hasPlugin  = !empty($s['secret_key']);
        $hasAppPass = !empty($s['wp_password']);
        $method     = $hasPlugin ? 'plugin' : ($hasAppPass ? 'apppass' : 'none');
        $methodLabel= $hasPlugin ? 'Plugin Key ✓' : ($hasAppPass ? 'App Password' : 'No Auth ✗');
        $methodClass= $hasPlugin ? 'tag-plugin' : ($hasAppPass ? 'tag-apppass' : 'tag-none');
      ?>
        <tr id="row-<?= $s['id'] ?>">
          <td><div style="font-weight:600"><?= htmlspecialchars($s['site_name']) ?></div></td>
          <td>
            <a href="<?= htmlspecialchars($s['site_url']) ?>" target="_blank"
               style="color:#3b82f6;font-size:13px">
              <?= htmlspecialchars($s['site_url']) ?>
            </a>
          </td>
          <td><span class="method-tag <?= $methodClass ?>"><?= $methodLabel ?></span></td>
          <td style="font-size:13px"><?= htmlspecialchars($s['default_category']) ?></td>
          <td>
            <span class="<?= $s['status']==='active' ? 'badge-suc' : 'badge-warn' ?>">
              <?= ucfirst($s['status']) ?>
            </span>
          </td>
          <td>
            <div style="display:flex;gap:5px">
              <button class="btn-sec btn-sm-nf" title="Edit"
                      onclick="showEditForm(<?= (int)$s['id'] ?>)">
                <i class="fa fa-edit"></i> Edit
              </button>
              <button class="btn-sec btn-sm-nf" title="Toggle status"
                      onclick="toggleStatus(<?= (int)$s['id'] ?>)">
                <i class="fa fa-power-off"></i>
              </button>
              <button class="btn-sec btn-sm-nf" title="Delete" style="color:#ef4444"
                      onclick="deleteSite(<?= (int)$s['id'] ?>, <?= htmlspecialchars(json_encode($s['site_name']), ENT_QUOTES) ?>)">
                <i class="fa fa-trash"></i>
              </button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<script>
// ── Show / hide form ──────────────────────────────────────────
function showAddForm() {
  document.getElementById('form-title').innerHTML = '<i class="fa fa-plus" style="color:#e94560;margin-right:8px"></i>Add WordPress Site';
  document.getElementById('f-id').value     = '';
  document.getElementById('f-name').value   = '';
  document.getElementById('f-url').value    = '';
  document.getElementById('f-user').value   = '';
  document.getElementById('f-pass').value   = '';
  document.getElementById('f-secret').value = '';
  document.getElementById('f-cat').value    = '';
  document.getElementById('f-status').value = 'active';
  document.getElementById('form-result').innerHTML      = '';
  document.getElementById('plugin-test-result').innerHTML = '';
  document.getElementById('apppass-test-result').innerHTML = '';
  document.getElementById('save-btn').innerHTML = '<i class="fa fa-save"></i> Save Site';
  document.getElementById('site-form').classList.add('open');
  document.getElementById('site-form').scrollIntoView({behavior:'smooth', block:'start'});
}

async function showEditForm(id) {
  // Show loading state on the button
  const btn = document.querySelector(`#row-${id} .btn-sec`);
  if (btn) { btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>'; btn.disabled = true; }

  let r;
  try {
    const resp = await fetch('api/sites.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({action: 'get', id: id})
    });
    r = await resp.json();
  } catch (e) {
    showToast('Network error loading site: ' + e.message, 'error');
    if (btn) { btn.innerHTML = '<i class="fa fa-edit"></i> Edit'; btn.disabled = false; }
    return;
  }

  if (btn) { btn.innerHTML = '<i class="fa fa-edit"></i> Edit'; btn.disabled = false; }

  if (!r || !r.success) {
    showToast('Could not load site: ' + (r?.error || 'Unknown error'), 'error');
    return;
  }

  const s = r.site;
  document.getElementById('form-title').innerHTML =
    '<i class="fa fa-edit" style="color:#e94560;margin-right:8px"></i>Edit: ' + s.site_name;
  document.getElementById('f-id').value     = s.id;
  document.getElementById('f-name').value   = s.site_name         || '';
  document.getElementById('f-url').value    = s.site_url          || '';
  document.getElementById('f-user').value   = s.wp_username       || '';
  document.getElementById('f-pass').value   = '';
  document.getElementById('f-secret').value = s.secret_key        || '';
  document.getElementById('f-cat').value    = s.default_category  || '';
  document.getElementById('f-status').value = s.status            || 'active';
  document.getElementById('form-result').innerHTML        = '';
  document.getElementById('plugin-test-result').innerHTML = '';
  document.getElementById('apppass-test-result').innerHTML= '';
  document.getElementById('save-btn').innerHTML = '<i class="fa fa-save"></i> Update Site';

  const form = document.getElementById('site-form');
  form.classList.add('open');
  form.scrollIntoView({behavior: 'smooth', block: 'start'});
}

function hideForm() {
  document.getElementById('site-form').classList.remove('open');
}

// ── Save (add or update) ─────────────────────────────────────
async function saveSite() {
  const id     = document.getElementById('f-id').value.trim();
  const name   = document.getElementById('f-name').value.trim();
  const url    = document.getElementById('f-url').value.trim();
  const user   = document.getElementById('f-user').value.trim();
  const pass   = document.getElementById('f-pass').value;
  const secret = document.getElementById('f-secret').value.trim();
  const cat    = document.getElementById('f-cat').value.trim();
  const status = document.getElementById('f-status').value;
  const res    = document.getElementById('form-result');

  if (!name) { res.innerHTML = err('Site name is required'); return; }
  if (!url)  { res.innerHTML = err('Site URL is required');  return; }
  if (!secret && !user) { res.innerHTML = err('Enter either the Plugin Secret Key or WP Username + Application Password'); return; }

  const btn = document.getElementById('save-btn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Saving...';
  res.innerHTML = '';

  const payload = {
    action: id ? 'edit' : 'add',
    site_name: name, site_url: url,
    wp_username: user, wp_password: pass,
    secret_key: secret,
    default_category: cat, status
  };
  if (id) payload.id = parseInt(id);

  const r = await fetch('api/sites.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  }).then(r => r.json());

  btn.disabled = false;
  btn.innerHTML = id ? '<i class="fa fa-save"></i> Update Site' : '<i class="fa fa-save"></i> Save Site';

  if (r.success) {
    showToast(r.message || 'Site saved!', 'success');
    hideForm();
    setTimeout(() => location.reload(), 1000);
  } else {
    res.innerHTML = err(r.error || 'Save failed');
  }
}

// ── Test plugin key ───────────────────────────────────────────
async function testPlugin() {
  const url    = document.getElementById('f-url').value.trim();
  const secret = document.getElementById('f-secret').value.trim();
  const res    = document.getElementById('plugin-test-result');

  if (!url)    { res.innerHTML = warn('Enter the site URL first'); return; }
  if (!secret) { res.innerHTML = warn('Enter the plugin secret key first'); return; }

  res.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Testing plugin connection...';

  const r = await fetch('api/sites.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({action:'test_plugin', site_url:url, secret_key:secret})
  }).then(r => r.json());

  res.innerHTML = r.success ? ok(r.message) : err(r.error);
}

// ── Test app password ─────────────────────────────────────────
async function testAppPass() {
  const url  = document.getElementById('f-url').value.trim();
  const user = document.getElementById('f-user').value.trim();
  const pass = document.getElementById('f-pass').value;
  const res  = document.getElementById('apppass-test-result');

  if (!url || !user || !pass) { res.innerHTML = warn('Fill URL, username and password first'); return; }
  res.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Testing...';

  const r = await fetch('api/sites.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({action:'test', site_url:url, wp_username:user, wp_password:pass})
  }).then(r => r.json());

  res.innerHTML = r.success ? ok(r.message) : err(r.error);
}

// ── Toggle / Delete ───────────────────────────────────────────
async function toggleStatus(id) {
  const r = await fetch('api/sites.php', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({action:'toggle', id})
  }).then(r => r.json());
  if (r.success) { showToast('Status updated to ' + r.status, 'success'); setTimeout(() => location.reload(), 800); }
  else showToast(r.error || 'Failed', 'error');
}

async function deleteSite(id, name) {
  if (!confirm(`Delete "${name}"?\n\nThis cannot be undone.`)) return;
  const r = await fetch('api/sites.php', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({action:'delete', id})
  }).then(r => r.json());
  if (r.success) { showToast('Site deleted', 'success'); setTimeout(() => location.reload(), 800); }
  else showToast(r.error || 'Delete failed', 'error');
}

// ── Helpers ───────────────────────────────────────────────────
function togglePassVis(id) {
  const el = document.getElementById(id);
  el.type = el.type === 'password' ? 'text' : 'password';
}
function ok(msg)   { return `<span style="color:#10b981"><i class="fa fa-check-circle"></i> ${msg}</span>`; }
function err(msg)  { return `<span style="color:#ef4444"><i class="fa fa-times-circle"></i> ${msg}</span>`; }
function warn(msg) { return `<span style="color:#f59e0b"><i class="fa fa-exclamation-triangle"></i> ${msg}</span>`; }
</script>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>

<?php
// publishers.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_admin();
$pageTitle='Publisher Management';$activePage='publishers';
// Handle add
if ($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['add_publisher'])) {
    $u=trim($_POST['username']??'');$fn=trim($_POST['fullname']??'');$e=trim($_POST['email']??'');$p=$_POST['password']??'';
    if ($u&&$p) {
        Database::query("INSERT INTO users (username,password,fullname,email,role,status) VALUES (?,?,?,?,'publisher','active')",[$u,password_hash($p,PASSWORD_BCRYPT),$fn,$e]);
        log_activity('Publisher Added',"Added publisher: $u");
        $msg='Publisher added successfully!';
    } else $err='Username and password required';
}
if (isset($_GET['toggle'])) {
    Database::query("UPDATE users SET status=IF(status='active','inactive','active') WHERE id=? AND role='publisher'",[(int)$_GET['toggle']]);
    header('Location: publishers.php');exit;
}
$publishers=Database::query("SELECT * FROM users WHERE role='publisher' ORDER BY id")->fetchAll();
include __DIR__ . '/includes/layout.php';
?>
<?php if(isset($msg)):?><div style="background:#d1fae5;color:#065f46;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:13.5px"><i class="fa fa-check-circle" style="margin-right:6px"></i><?=htmlspecialchars($msg)?></div><?php endif;?>
<?php if(isset($err)):?><div style="background:#fee2e2;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:13.5px"><?=htmlspecialchars($err)?></div><?php endif;?>
<div style="display:flex;justify-content:flex-end;margin-bottom:20px">
  <button class="btn-primary-nf" onclick="showModal(addPublisherForm())"><i class="fa fa-user-plus"></i> Add Publisher</button>
</div>
<div class="card">
  <div class="card-header">Publishers (<?=count($publishers)?>)</div>
  <div class="card-body" style="padding:0">
    <table class="data-table">
      <thead><tr><th>Publisher</th><th>Email</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach($publishers as $p):?>
        <tr>
          <td><div style="display:flex;align-items:center;gap:10px"><div style="width:30px;height:30px;border-radius:50%;background:#e94560;display:flex;align-items:center;justify-content:center;color:white;font-weight:600;font-size:11px"><?=strtoupper(substr($p['fullname'],0,2))?></div><div><div style="font-weight:600;font-size:13px"><?=htmlspecialchars($p['fullname'])?></div><div style="font-size:12px;color:var(--text2)"><?=htmlspecialchars($p['username'])?></div></div></div></td>
          <td style="font-size:13px"><?=htmlspecialchars($p['email'])?></td>
          <td><span class="<?=$p['status']==='active'?'badge-suc':'badge-warn'?>"><?=ucfirst($p['status'])?></span></td>
          <td style="font-size:12px;color:var(--text2)"><?=date('d M Y',strtotime($p['created_date']))?></td>
          <td><div style="display:flex;gap:6px">
            <a href="publishers.php?toggle=<?=$p['id']?>" class="btn-sec btn-sm-nf" title="Toggle status"><i class="fa fa-power-off"></i></a>
          </div></td>
        </tr>
      <?php endforeach;?>
      </tbody>
    </table>
  </div>
</div>
<form id="add-pub-form" method="POST" style="display:none"></form>
<script>
function addPublisherForm(){
  return `<div style="font-size:18px;font-weight:700;margin-bottom:20px"><i class="fa fa-user-plus" style="color:#e94560;margin-right:8px"></i>Add Publisher</div>
  <form method="POST">
    <div class="grid-2">
      <div class="form-group"><label>Username *</label><input type="text" name="username" class="inp" required placeholder="publisher5"></div>
      <div class="form-group"><label>Full Name</label><input type="text" name="fullname" class="inp" placeholder="Full Name"></div>
    </div>
    <div class="form-group"><label>Email</label><input type="email" name="email" class="inp" placeholder="email@example.com"></div>
    <div class="form-group"><label>Password *</label><input type="password" name="password" class="inp" required placeholder="Min 8 chars"></div>
    <button type="submit" name="add_publisher" class="btn-primary-nf" style="width:100%;justify-content:center"><i class="fa fa-user-plus"></i> Add Publisher</button>
  </form>`;
}
</script>
<?php require __DIR__.'/includes/layout_footer.php'; ?>

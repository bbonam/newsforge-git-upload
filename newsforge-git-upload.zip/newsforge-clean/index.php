<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

// Auto-install schema on first run
try { install_schema(); } catch(Exception $e) { /* will show DB error below */ }

// Handle login POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    if (do_login(trim($_POST['username']), $_POST['password'])) {
        header('Location: ' . APP_URL . '/dashboard.php');
        exit;
    }
    $loginError = 'Invalid username or password';
}

// Redirect if already logged in
if (is_logged_in()) {
    header('Location: ' . APP_URL . '/dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title><?= APP_NAME ?> — Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;min-height:100vh;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);display:flex;align-items:center;justify-content:center}
.auth-card{background:white;border-radius:16px;padding:44px 40px;width:400px;box-shadow:0 20px 60px rgba(0,0,0,.35)}
.brand{font-family:'Playfair Display',serif;font-size:28px;color:#1a1a2e;margin-bottom:4px}
.brand span{color:#e94560}
.sub{color:#6b7280;font-size:13px;margin-bottom:30px}
.form-label{font-size:13px;font-weight:500;color:#6b7280}
.form-control{border-radius:8px;border:1.5px solid #e5e7eb;padding:10px 14px;font-size:14px;transition:.2s}
.form-control:focus{border-color:#e94560;box-shadow:0 0 0 3px rgba(233,69,96,.12)}
.btn-login{background:#e94560;color:white;border:none;border-radius:8px;padding:12px;font-weight:600;font-size:14px;width:100%;cursor:pointer;transition:.2s;margin-top:4px}
.btn-login:hover{background:#d63651}
.hint{background:#f8f9fb;border-radius:8px;padding:10px 14px;font-size:12px;color:#9ca3af;margin-top:14px;border:1px solid #e5e7eb}
.hint strong{color:#6b7280}
.error-msg{color:#ef4444;font-size:13px;margin-top:10px}
</style>
</head>
<body>
<div class="auth-card">
  <div class="brand">News<span>Forge</span> AI</div>
  <div class="sub">Multi-WordPress AI Publishing Platform</div>

  <?php if (isset($loginError)): ?>
    <div class="error-msg"><i class="fa fa-exclamation-circle"></i> <?= htmlspecialchars($loginError) ?></div>
  <?php endif; ?>

  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="mb-3">
      <label class="form-label">Username</label>
      <input type="text" name="username" class="form-control" placeholder="Enter username" required autofocus
             value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
    </div>
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" placeholder="••••••••" required>
    </div>
    <button type="submit" class="btn-login">Sign In →</button>
  </form>

  <div class="hint">
    <strong>Admin:</strong> admin / admin123 &nbsp;|&nbsp; <strong>Publisher:</strong> publisher1 / publisher123
  </div>
</div>
</body>
</html>

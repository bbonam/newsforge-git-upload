<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$pageTitle  = 'AI Content Generator';
$activePage = 'ai-generate';
include __DIR__ . '/includes/layout.php';
?>
<div style="display:grid;grid-template-columns:1fr 380px;gap:20px">
  <div>
    <div class="card mb-3">
      <div class="card-header">Source Article</div>
      <div class="card-body" id="source-display">
        <div style="text-align:center;padding:30px;color:var(--text2)">
          <i class="fa fa-newspaper" style="font-size:36px;display:block;margin-bottom:12px;color:#d1d5db"></i>
          <div style="font-weight:600;margin-bottom:6px">No article selected</div>
          <div style="font-size:13px;margin-bottom:14px">Go to Search News and click "AI Generate" on an article</div>
          <a href="news-search.php" class="btn-sec btn-sm-nf"><i class="fa fa-search"></i> Search News</a>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">AI Configuration</div>
      <div class="card-body">
        <div class="grid-2">
          <div class="form-group">
            <label>Language</label>
            <select class="inp" id="ai-lang">
              <option value="English">English</option>
              <option value="Telugu">Telugu (తెలుగు)</option>
            </select>
          </div>
          <div class="form-group">
            <label>AI Engine</label>
            <select class="inp" id="ai-engine">
              <option value="claude">Claude (Anthropic)</option>
              <option value="openai">OpenAI GPT-4o</option>
              <option value="gemini">Google Gemini</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label>Writing Style</label>
          <select class="inp" id="ai-style">
            <option value="rewrite">Rewrite in Telugu News Style</option>
            <option value="seo">SEO Optimized Article</option>
            <option value="humanized">Humanized & Engaging</option>
            <option value="longform">Long Form Detailed Article</option>
            <option value="summary">Short News Summary</option>
          </select>
        </div>
        <div class="form-group">
          <label>Additional Instructions (optional)</label>
          <textarea class="inp" id="ai-extra" rows="2" placeholder="e.g. Focus on political impact, add expert quotes..."></textarea>
        </div>
        <button class="btn-primary-nf" onclick="generateContent()" id="gen-btn" style="width:100%;justify-content:center">
          <i class="fa fa-magic"></i> Generate AI Content
        </button>
      </div>
    </div>
  </div>

  <div class="card" style="position:sticky;top:80px;align-self:start">
    <div class="card-header">Generated Output</div>
    <div id="ai-output" style="padding:16px;min-height:300px">
      <div style="text-align:center;padding:40px;color:var(--text2)">
        <i class="fa fa-magic" style="font-size:32px;display:block;margin-bottom:10px;color:#d1d5db"></i>
        <div style="font-size:13px">Configure settings and click Generate</div>
      </div>
    </div>
    <div id="ai-actions" style="display:none;padding:14px;border-top:1px solid var(--border)">
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn-sec btn-sm-nf" onclick="openEditor()"><i class="fa fa-edit"></i> Edit</button>
        <button class="btn-sec btn-sm-nf" onclick="generateContent()"><i class="fa fa-redo"></i> Regenerate</button>
        <button class="btn-primary-nf btn-sm-nf" onclick="goPublish()"><i class="fa fa-paper-plane"></i> Publish</button>
      </div>
    </div>
  </div>
</div>

<script>
let articleData = null;
let generatedData = null;
let savedArticleId = null;

// Load article from session storage
window.onload = () => {
  const stored = sessionStorage.getItem('selectedArticle');
  if (stored) {
    articleData = JSON.parse(stored);
    // Clear any previous generated content — new article means fresh start
    sessionStorage.removeItem('generatedArticle');
    sessionStorage.removeItem('publishArticleId');
    sessionStorage.removeItem('editorContent');
    document.getElementById('source-display').innerHTML = `
      <div><div style="font-weight:700;font-size:15px;margin-bottom:8px;line-height:1.4">${articleData.title}</div>
      <div style="font-size:12px;color:#e94560;font-weight:600;margin-bottom:8px">${articleData.source}</div>
      <div style="font-size:13px;color:var(--text2);line-height:1.6;max-height:180px;overflow-y:auto">${(articleData.content||'').substring(0,600)}...</div></div>`;
  }
};

async function generateContent(){
  if(!articleData){showToast('Please select an article from Search News first','error');return;}
  const btn=document.getElementById('gen-btn');
  btn.disabled=true;btn.innerHTML='<span style="display:inline-flex;align-items:center;gap:8px"><span style="width:16px;height:16px;border:2px solid rgba(255,255,255,.3);border-top-color:white;border-radius:50%;animation:spin .6s linear infinite;display:inline-block"></span> Generating...</span>';
  document.getElementById('ai-output').innerHTML='<div style="text-align:center;padding:50px;color:var(--text2)"><div style="width:28px;height:28px;border:3px solid #e5e7eb;border-top-color:#e94560;border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 14px"></div><div>Claude is writing your article...</div><div style="font-size:12px;margin-top:6px;color:#9ca3af">15–30 seconds</div></div>';
  document.getElementById('ai-actions').style.display='none';

  const resp = await fetch('api/generate.php',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({
      engine:   document.getElementById('ai-engine').value,
      language: document.getElementById('ai-lang').value,
      style:    document.getElementById('ai-style').value,
      extra:    document.getElementById('ai-extra').value,
      title:    articleData.title,
      content:  articleData.content,
      imageUrl: articleData.image || '',
      sourceUrl:articleData.url||''
    })
  });
  const data=await resp.json();
  btn.disabled=false;btn.innerHTML='<i class="fa fa-magic"></i> Generate AI Content';

  if(data.error){showToast(data.error,'error');document.getElementById('ai-output').innerHTML=`<div style="padding:16px;color:#991b1b;font-size:13px"><i class="fa fa-exclamation-circle" style="margin-right:6px"></i>${data.error}</div>`;return;}

  generatedData=data.data;
  savedArticleId=data.article_id;

  // Image: prefer API-returned image (DALL-E/Unsplash), then scraped, then none
  const finalImageUrl = data.image_url || data.data?.image_url || articleData.image || '';
  sessionStorage.setItem('generatedArticle', JSON.stringify({
    ...data.data, article_id: data.article_id, image_url: finalImageUrl
  }));

  // Build image section with source label
  let imageHtml = '';
  if (finalImageUrl) {
    const eng = document.getElementById('ai-engine').value;
    const wasScraped = finalImageUrl === (articleData.image || '');
    const srcLabel = wasScraped
      ? '<span style="background:#f0fdf4;color:#065f46;font-size:11px;padding:2px 8px;border-radius:10px"><i class="fa fa-link"></i> Scraped from source</span>'
      : eng === 'openai'
        ? '<span style="background:#d1fae5;color:#065f46;font-size:11px;padding:2px 8px;border-radius:10px"><i class="fa fa-magic"></i> DALL-E 3 generated</span>'
        : '<span style="background:#dbeafe;color:#1e40af;font-size:11px;padding:2px 8px;border-radius:10px"><i class="fa fa-image"></i> Unsplash photo</span>';
    imageHtml = `<div style="margin-bottom:12px">
      <img src="${finalImageUrl}" style="width:100%;height:160px;object-fit:cover;border-radius:8px;display:block"
           onerror="this.parentElement.innerHTML=brandedImagePrompt(${data.article_id})">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-top:5px">
        ${srcLabel}
        <button class="btn-sec btn-sm-nf" style="font-size:11px" onclick="generateBrandedImage(${data.article_id})">
          <i class="fa fa-redo"></i> Replace
        </button>
      </div>
    </div>`;
  } else {
    imageHtml = `<div style="margin-bottom:12px">${brandedImagePrompt(data.article_id)}</div>`;
  }

  document.getElementById('ai-output').innerHTML=`
    <div style="padding:4px">
      ${imageHtml}
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:5px">SEO TITLE</div>
      <div style="font-size:15px;font-weight:700;margin-bottom:14px;line-height:1.4">${data.data.seoTitle||articleData.title}</div>
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:5px">ARTICLE</div>
      <div style="font-size:13px;line-height:1.7;max-height:280px;overflow-y:auto;background:#f8f9fb;border-radius:8px;padding:12px">${data.data.body||''}</div>
      ${data.data.metaDescription?`<div style="margin-top:10px;padding:8px;background:#eff6ff;border-radius:6px;font-size:12px;color:#1e40af"><strong>Meta:</strong> ${data.data.metaDescription}</div>`:''}
      ${data.data.tags?`<div style="margin-top:8px">${data.data.tags.split(',').map(t=>`<span style="display:inline-block;background:#f1f3f7;color:var(--text2);border-radius:20px;padding:2px 8px;font-size:11px;margin:2px">${t.trim()}</span>`).join('')}</div>`:''}
    </div>`;
  document.getElementById('ai-actions').style.display='block';
  showToast('Content generated successfully!','success');
}

function openEditor(){
  if(!generatedData){return;}
  sessionStorage.setItem('editorContent',JSON.stringify(generatedData));
  window.location.href='editor.php';
}

function goPublish(){
  if(!savedArticleId){showToast('Generate content first','error');return;}
  sessionStorage.setItem('publishArticleId',savedArticleId);
  window.location.href='publish.php';
}

function brandedImagePrompt(articleId) {
  return `<div style="background:#f8f9fb;border:1.5px dashed #e5e7eb;border-radius:8px;padding:14px;text-align:center">
    <i class="fa fa-image" style="font-size:24px;color:#d1d5db;display:block;margin-bottom:8px"></i>
    <div style="font-size:13px;color:#6b7280;margin-bottom:10px">No featured image found for this article</div>
    <button class="btn-primary-nf btn-sm-nf" onclick="generateBrandedImage(${articleId})" id="gen-img-btn">
      <i class="fa fa-paint-brush"></i> Generate Branded Image
    </button>
    <div id="img-gen-result" style="margin-top:8px;font-size:12px;color:#6b7280"></div>
  </div>`;
}

async function generateBrandedImage(articleId) {
  const btn = document.getElementById('gen-img-btn');
  const res = document.getElementById('img-gen-result');
  if (!btn) return;
  btn.disabled = true;
  btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Generating...';

  // Get site name from the first selected site (or default)
  const siteName = 'AP News Daily';
  const category = document.getElementById('news-cat')?.value || 'News';

  const r = await fetch('api/image.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      article_id: articleId,
      title:      articleData?.title || '',
      site_name:  siteName,
      category:   category,
    })
  }).then(r => r.json());

  if (r.success) {
    // Replace the prompt with the generated image
    const wrap = btn.closest('div[style]');
    if (wrap) {
      wrap.innerHTML = `
        <img src="${r.image_url}" style="width:100%;height:140px;object-fit:cover;border-radius:8px;display:block">
        <div style="font-size:11px;color:#10b981;margin-top:4px"><i class="fa fa-check-circle"></i> Branded image generated</div>
        <button class="btn-sec btn-sm-nf" style="margin-top:6px;font-size:11px" onclick="generateBrandedImage(${articleId})">
          <i class="fa fa-redo"></i> Regenerate
        </button>`;
    }
    // Update sessionStorage with image URL
    const stored = sessionStorage.getItem('generatedArticle');
    if (stored) {
      const d = JSON.parse(stored);
      d.image_url = r.image_url;
      sessionStorage.setItem('generatedArticle', JSON.stringify(d));
    }
    showToast('Branded image generated!', 'success');
  } else {
    btn.disabled = false;
    btn.innerHTML = '<i class="fa fa-paint-brush"></i> Generate Branded Image';
    if (res) res.textContent = r.error || 'Generation failed';
  }
}
</script>
<style>@keyframes spin{to{transform:rotate(360deg)}}</style>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>

<?php
/**
 * Plugin Name: NewsForge Publisher
 * Plugin URI:  https://newsforge.ai
 * Description: Allows NewsForge AI platform to publish articles via a secure secret key. No Application Passwords needed.
 * Version:     1.0.0
 * Author:      NewsForge
 */

if (!defined('ABSPATH')) exit;

// ── 1. Let admin set the secret key from WP Admin ─────────────
add_action('admin_menu', function () {
    add_options_page(
        'NewsForge Publisher',
        'NewsForge Publisher',
        'manage_options',
        'newsforge-publisher',
        'newsforge_settings_page'
    );
});

function newsforge_settings_page() {
    if (isset($_POST['newsforge_save']) && check_admin_referer('newsforge_save')) {
        $key = sanitize_text_field(trim($_POST['newsforge_secret_key']));
        if ($key) update_option('newsforge_secret_key', $key);
        echo '<div class="updated"><p>Secret key saved!</p></div>';
    }
    $key = get_option('newsforge_secret_key', '');
    ?>
    <div class="wrap">
      <h1>NewsForge Publisher Settings</h1>
      <p>Copy this secret key into <strong>NewsForge → WordPress Sites → Secret Key</strong> field for this site.</p>
      <form method="POST">
        <?php wp_nonce_field('newsforge_save'); ?>
        <table class="form-table">
          <tr>
            <th>Secret Key</th>
            <td>
              <input type="text" name="newsforge_secret_key" value="<?= esc_attr($key) ?>"
                     class="regular-text" placeholder="Paste or generate a key">
              <p class="description">
                Generate a strong key:
                <code><?= wp_generate_password(32, false) ?></code>
                (copy this and paste above)
              </p>
            </td>
          </tr>
        </table>
        <?php submit_button('Save Key', 'primary', 'newsforge_save'); ?>
      </form>

      <hr>
      <h2>Connection Details</h2>
      <table class="form-table">
        <tr><th>Endpoint URL</th><td><code><?= esc_url(rest_url('newsforge/v1/publish')) ?></code></td></tr>
        <tr><th>Site URL</th><td><code><?= esc_url(get_site_url()) ?></code></td></tr>
        <tr><th>Status</th><td><?= $key ? '<span style="color:green">✓ Key configured</span>' : '<span style="color:red">✗ No key set</span>' ?></td></tr>
      </table>
    </div>
    <?php
}

// ── 2. Register REST API endpoint ─────────────────────────────
add_action('rest_api_init', function () {

    // Publish endpoint
    register_rest_route('newsforge/v1', '/publish', [
        'methods'             => 'POST',
        'callback'            => 'newsforge_publish_post',
        'permission_callback' => 'newsforge_verify_key',
    ]);

    // Test / ping endpoint
    register_rest_route('newsforge/v1', '/ping', [
        'methods'             => 'POST',
        'callback'            => function () {
            return rest_ensure_response([
                'success'  => true,
                'message'  => 'NewsForge Publisher plugin connected!',
                'site_url' => get_site_url(),
                'wp_ver'   => get_bloginfo('version'),
            ]);
        },
        'permission_callback' => 'newsforge_verify_key',
    ]);

    // Get categories
    register_rest_route('newsforge/v1', '/categories', [
        'methods'             => 'GET',
        'callback'            => function () {
            $cats = get_categories(['hide_empty' => false]);
            $list = array_map(fn($c) => ['id' => $c->term_id, 'name' => $c->name], $cats);
            return rest_ensure_response(['success' => true, 'categories' => $list]);
        },
        'permission_callback' => 'newsforge_verify_key',
    ]);
});

// ── 3. Verify secret key (passed as header OR query param) ─────
function newsforge_verify_key(WP_REST_Request $request): bool {
    $stored = get_option('newsforge_secret_key', '');
    if (!$stored) return false;

    // Accept key from X-NewsForge-Key header OR ?nf_key= query param
    $provided = $request->get_header('X-NewsForge-Key')
              ?? $request->get_param('nf_key')
              ?? '';

    return hash_equals($stored, trim($provided));
}

// ── 4. Publish handler ────────────────────────────────────────
function newsforge_publish_post(WP_REST_Request $request): WP_REST_Response {
    $params = $request->get_json_params();

    $title       = sanitize_text_field($params['title']       ?? '');
    $content     = wp_kses_post($params['content']            ?? '');
    $excerpt     = sanitize_text_field($params['excerpt']     ?? '');
    $status      = in_array($params['status'] ?? '', ['publish','draft','future']) ? $params['status'] : 'publish';
    $categoryStr = sanitize_text_field($params['category']    ?? '');
    $tagsStr     = sanitize_text_field($params['tags']        ?? '');
    $scheduleAt  = sanitize_text_field($params['schedule_at'] ?? '');
    $seoTitle    = sanitize_text_field($params['seo_title']   ?? $title);
    $metaDesc    = sanitize_text_field($params['meta_desc']   ?? $excerpt);

    if (!$title || !$content) {
        return new WP_REST_Response(['success' => false, 'error' => 'title and content are required'], 400);
    }

    // ── Resolve or create category ────────────────────────────
    $categoryId = null;
    if ($categoryStr) {
        $cat = get_category_by_slug(sanitize_title($categoryStr));
        if (!$cat) {
            $existing = get_term_by('name', $categoryStr, 'category');
            $cat = $existing ?: null;
        }
        if ($cat) {
            $categoryId = $cat->term_id;
        } else {
            $newCat = wp_insert_term($categoryStr, 'category');
            if (!is_wp_error($newCat)) $categoryId = $newCat['term_id'];
        }
    }

    // ── Resolve or create tags ────────────────────────────────
    $tagIds = [];
    if ($tagsStr) {
        foreach (array_slice(array_map('trim', explode(',', $tagsStr)), 0, 10) as $tagName) {
            if (!$tagName) continue;
            $term = get_term_by('name', $tagName, 'post_tag');
            if ($term) {
                $tagIds[] = $term->term_id;
            } else {
                $newTag = wp_insert_term($tagName, 'post_tag');
                if (!is_wp_error($newTag)) $tagIds[] = $newTag['term_id'];
            }
        }
    }

    // ── Upload featured image ─────────────────────────────────
    $featuredMediaId = null;
    $imageUrl = !empty($params['image_url']) ? esc_url_raw($params['image_url']) : '';

    if ($imageUrl) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = download_url($imageUrl, 30);
        if (!is_wp_error($tmp)) {
            $filename = !empty($params['image_filename'])
                ? sanitize_file_name($params['image_filename'])
                : 'newsforge-' . time() . '.jpg';
            $file    = ['name' => $filename, 'tmp_name' => $tmp, 'error' => 0, 'size' => filesize($tmp)];
            $mediaId = media_handle_sideload($file, 0, $postTitle);
            @unlink($tmp);
            if (!is_wp_error($mediaId)) {
                $featuredMediaId = $mediaId;
            }
        }
    }

    // ── Build post array ──────────────────────────────────────
    $postArr = [
        'post_title'   => $title,
        'post_content' => $content,
        'post_excerpt' => $excerpt,
        'post_status'  => $status,
        'post_author'  => get_current_user_id() ?: 1,
        'post_type'    => 'post',
        'comment_status' => 'open',
    ];

    if ($categoryId)     $postArr['post_category'] = [$categoryId];
    if (!empty($tagIds)) $postArr['tags_input']     = $tagIds;
    if ($status === 'future' && $scheduleAt) {
        $postArr['post_date']     = get_date_from_gmt(date('Y-m-d H:i:s', strtotime($scheduleAt)));
        $postArr['post_date_gmt'] = date('Y-m-d H:i:s', strtotime($scheduleAt));
    }

    // ── Insert post ───────────────────────────────────────────
    $postId = wp_insert_post($postArr, true);
    if (is_wp_error($postId)) {
        return new WP_REST_Response(['success' => false, 'error' => $postId->get_error_message()], 500);
    }

    if ($featuredMediaId) set_post_thumbnail($postId, $featuredMediaId);

    // ── Yoast SEO meta (if plugin active) ─────────────────────
    if (defined('WPSEO_VERSION')) {
        update_post_meta($postId, '_yoast_wpseo_title',    $seoTitle);
        update_post_meta($postId, '_yoast_wpseo_metadesc', $metaDesc);
    }

    // ── RankMath SEO (if plugin active) ───────────────────────
    if (defined('RANK_MATH_VERSION')) {
        update_post_meta($postId, 'rank_math_title',            $seoTitle);
        update_post_meta($postId, 'rank_math_description',      $metaDesc);
        update_post_meta($postId, 'rank_math_focus_keyword',    explode(',', $tagsStr)[0] ?? '');
    }

    return new WP_REST_Response([
        'success'    => true,
        'post_id'    => $postId,
        'post_url'   => get_permalink($postId),
        'status'     => $status,
        'title'      => get_the_title($postId),
        'category'   => $categoryId,
        'tags'       => count($tagIds),
        'image'      => $featuredMediaId ? wp_get_attachment_url($featuredMediaId) : null,
    ], 201);
}

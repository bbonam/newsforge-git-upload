<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$pageTitle  = 'Search News';
$activePage = 'news-search';
include __DIR__ . '/includes/layout.php';
?>
<div class="card mb-4">
  <div class="card-header">Search Latest News</div>
  <div class="card-body">
    <div style="display:grid;grid-template-columns:1fr 1fr 200px;gap:12px;align-items:flex-end">
      <div class="form-group mb-0">
        <label>Category</label>
        <select class="inp" id="news-cat">
          <option>Andhra Pradesh</option><option>Telangana</option><option>Cricket</option>
          <option>Technology</option><option>Artificial Intelligence</option><option>Politics</option>
          <option>Business</option><option>Entertainment</option><option>Education</option>
        </select>
      </div>
      <div class="form-group mb-0">
        <label>Keywords</label>
        <input type="text" class="inp" id="news-kw" placeholder="e.g. CM Jagan, Budget 2025, YSRCP">
      </div>
      <div class="form-group mb-0">
        <label>News Source</label>
        <select class="inp" id="news-source">
          <option value="newsapi">📰 NewsAPI.org</option>
          <option value="rss">📡 Google News RSS</option>
          <option value="both">🔀 Both (NewsAPI first)</option>
        </select>
      </div>
    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:10px">
      <button class="btn-primary-nf" onclick="searchNews()" id="search-btn">
        <i class="fa fa-search"></i> Search Latest News
      </button>
      <div id="news-source-badge" style="font-size:12px"></div>
    </div>
  </div>
</div>

<div id="news-loading" style="display:none;text-align:center;padding:50px;color:var(--text2)">
  <div style="width:28px;height:28px;border:3px solid #e5e7eb;border-top-color:#e94560;border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 12px"></div>
  <div>Fetching latest news...</div>
</div>
<div id="news-error" style="display:none;background:#fef2f2;border:1px solid #fca5a5;border-radius:10px;padding:16px 20px;margin-bottom:16px">
  <div style="font-weight:600;color:#991b1b;margin-bottom:4px"><i class="fa fa-times-circle" style="margin-right:6px"></i><span id="news-error-title">Error</span></div>
  <div style="font-size:13px;color:#7f1d1d" id="news-error-msg"></div>
  <div style="font-size:12px;color:#991b1b;margin-top:8px">
    Fix: Go to <a href="api-settings.php" style="color:#991b1b;font-weight:600">API Settings</a> and save your NewsAPI key — or switch source to <strong>Google News RSS</strong>
  </div>
</div>
<div id="news-empty" style="text-align:center;padding:60px;color:var(--text2)">
  <i class="fa fa-newspaper" style="font-size:40px;display:block;margin-bottom:14px;color:#d1d5db"></i>
  <div style="font-size:15px;font-weight:600;margin-bottom:6px;color:#1a1a2e">Search for news to get started</div>
  <div style="font-size:13px">Select a source, enter keywords, then click Search</div>
</div>
<div id="news-results" style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px"></div>

<style>
@keyframes spin{to{transform:rotate(360deg)}}
.news-card{background:white;border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;transition:.2s}
.news-card:hover{box-shadow:0 6px 24px rgba(0,0,0,.1);transform:translateY(-2px)}
.ni{width:100%;height:160px;background:#f1f3f7;display:flex;align-items:center;justify-content:center;color:#d1d5db;font-size:32px;overflow:hidden}
.ni img{width:100%;height:100%;object-fit:cover}
.nb{padding:14px}
.ns{font-size:11px;color:#e94560;font-weight:600;text-transform:uppercase;margin-bottom:5px}
.nt{font-size:14px;font-weight:600;line-height:1.4;margin-bottom:7px}
.nsu{font-size:12.5px;color:var(--text2);line-height:1.5}
.nm{display:flex;align-items:center;justify-content:space-between;margin-top:10px;padding-top:10px;border-top:1px solid var(--border)}
</style>
<script>
async function searchNews(){
  const cat    = document.getElementById('news-cat').value;
  const kw     = document.getElementById('news-kw').value;
  const source = document.getElementById('news-source').value;
  const btn    = document.getElementById('search-btn');

  document.getElementById('news-results').innerHTML = '';
  document.getElementById('news-empty').style.display   = 'none';
  document.getElementById('news-error').style.display   = 'none';
  document.getElementById('news-loading').style.display = 'block';
  document.getElementById('news-source-badge').innerHTML = '';

  btn.disabled = true;
  btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Searching...';

  try {
    const resp = await fetch(
      `api/news.php?category=${encodeURIComponent(cat)}&keywords=${encodeURIComponent(kw)}&source=${source}`
    );
    const data = await resp.json();

    document.getElementById('news-loading').style.display = 'none';
    btn.disabled  = false;
    btn.innerHTML = '<i class="fa fa-search"></i> Search Latest News';

    // Handle API-level error (e.g. bad NewsAPI key)
    if (!data.success) {
      document.getElementById('news-error-title').textContent = 'News fetch failed';
      document.getElementById('news-error-msg').textContent   = data.error || 'Unknown error';
      document.getElementById('news-error').style.display     = 'block';
      return;
    }

    if (data.articles && data.articles.length > 0) {
      // Source badge
      const badges = {
        newsapi : '📰 <strong>NewsAPI.org</strong> — real images included',
        rss     : '📡 <strong>Google News RSS</strong> — images may be limited',
        mock    : '⚠️ <strong>Demo data</strong> — add a NewsAPI key for real results',
      };
      const badgeColors = { newsapi:'#d1fae5;color:#065f46', rss:'#fef3c7;color:#92400e', mock:'#fee2e2;color:#991b1b' };
      const src = data.source || source;
      document.getElementById('news-source-badge').innerHTML =
        `<span style="background:${badgeColors[src] || '#f1f3f7;color:#6b7280'};font-size:12px;padding:3px 12px;border-radius:20px">
           ${badges[src] || src}
         </span>`;
      renderArticles(data.articles);
    } else {
      document.getElementById('news-empty').style.display = 'block';
    }

  } catch(e) {
    document.getElementById('news-loading').style.display = 'none';
    btn.disabled  = false;
    btn.innerHTML = '<i class="fa fa-search"></i> Search Latest News';
    document.getElementById('news-error-title').textContent = 'Network error';
    document.getElementById('news-error-msg').textContent   = e.message;
    document.getElementById('news-error').style.display     = 'block';
  }
}

function renderArticles(articles){
  const container=document.getElementById('news-results');
  container.innerHTML='';
  articles.forEach(art=>{
    const d=document.createElement('div');
    d.className='news-card';
    const escaped=JSON.stringify(art).replace(/'/g,"&#39;");
    const imgBadge = art.has_image
      ? '<span style="position:absolute;top:8px;right:8px;background:rgba(0,0,0,0.55);color:white;font-size:10px;padding:2px 7px;border-radius:8px"><i class="fa fa-image"></i> Image</span>'
      : '';
    d.innerHTML=`
      <div class="ni" style="position:relative">
        ${art.image
          ? `<img src="${art.image}" onerror="this.parentElement.innerHTML='<i class=\\'fa fa-newspaper\\'></i>'">`
          : '<i class="fa fa-newspaper"></i>'}
        ${imgBadge}
      </div>
      <div class="nb">
        <div class="ns">${art.source||'News'}</div>
        <div class="nt">${art.title}</div>
        <div class="nsu">${art.summary||''}</div>
        <div class="nm">
          <span style="font-size:11px;color:#9ca3af"><i class="fa fa-clock" style="margin-right:3px"></i>${art.date}</span>
          <button class="btn-primary-nf btn-sm-nf" onclick='selectAndGenerate(${escaped})'>
            <i class="fa fa-magic"></i> AI Generate
          </button>
        </div>
      </div>`;
    container.appendChild(d);
  });
}

function selectAndGenerate(art){
  sessionStorage.setItem('selectedArticle', JSON.stringify(art));
  window.location.href='ai-generate.php';
}

document.getElementById('news-kw').addEventListener('keypress',e=>{if(e.key==='Enter')searchNews()});
</script>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>

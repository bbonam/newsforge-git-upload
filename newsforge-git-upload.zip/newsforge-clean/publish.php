<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$pageTitle  = 'Publish Content';
$activePage = 'publish';
$sites = Database::query("SELECT * FROM wordpress_sites WHERE status='active' ORDER BY site_name")->fetchAll();
// Last 10 published records for this user
$user = current_user();
$recentPubs = Database::query(
    "SELECT pp.*, a.title, a.seo_title, ws.site_name, ws.site_url
     FROM published_posts pp
     JOIN articles a  ON pp.article_id = a.id
     JOIN wordpress_sites ws ON pp.site_id = ws.id
     WHERE a.created_by = ?
     ORDER BY pp.id DESC LIMIT 10",
    [$user['id']]
)->fetchAll();
include __DIR__ . '/includes/layout.php';
?>

<div class="grid-2" style="margin-bottom:20px">

  <!-- LEFT: Article preview + options -->
  <div class="card">
    <div class="card-header"><i class="fa fa-file-alt" style="color:#e94560;margin-right:8px"></i>Article to Publish</div>
    <div class="card-body">
      <div id="no-article" style="text-align:center;padding:30px;color:var(--text2)">
        <i class="fa fa-exclamation-circle" style="font-size:32px;display:block;margin-bottom:10px;color:#f59e0b"></i>
        <div style="font-weight:600;margin-bottom:6px">No article loaded</div>
        <div style="font-size:13px;margin-bottom:14px">Generate AI content first, then come here to publish</div>
        <a href="ai-generate.php" class="btn-primary-nf btn-sm-nf"><i class="fa fa-magic"></i> Go Generate</a>
      </div>
      <div id="article-preview" style="display:none">
        <div id="pub-title" style="font-size:17px;font-weight:700;margin-bottom:10px;line-height:1.4;color:#1a1a2e"></div>
        <div id="pub-body" style="font-size:13px;color:var(--text2);line-height:1.6;max-height:200px;overflow-y:auto;background:#f8f9fb;border-radius:8px;padding:12px;margin-bottom:14px"></div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;font-size:12px">
          <span id="pub-lang" style="background:#eff6ff;color:#1e40af;padding:3px 8px;border-radius:20px"></span>
          <span id="pub-engine" style="background:#f0fdf4;color:#065f46;padding:3px 8px;border-radius:20px"></span>
          <span id="pub-tags" style="color:#6b7280"></span>
        </div>
      </div>

      <!-- Publish settings -->
      <div id="pub-settings" style="display:none;margin-top:16px;padding-top:16px;border-top:1px solid var(--border)">
        <div class="form-group mb-2">
          <label>Publish Mode</label>
          <select class="inp" id="pub-mode"
                  onchange="document.getElementById('sch-wrap').style.display=this.value==='schedule'?'block':'none'">
            <option value="publish">Publish Immediately</option>
            <option value="draft">Save as Draft in WordPress</option>
            <option value="schedule">Schedule for Later</option>
          </select>
        </div>
        <div id="sch-wrap" style="display:none" class="form-group mb-0">
          <label>Schedule Date &amp; Time</label>
          <input type="datetime-local" class="inp" id="pub-sched">
        </div>
      </div>

      <!-- ── FEATURED IMAGE UPLOAD ── -->
      <div id="pub-settings-img" style="display:none;margin-top:16px;padding-top:16px;border-top:1px solid var(--border)">
        <div style="font-size:13px;font-weight:600;color:#1a1a2e;margin-bottom:10px">
          <i class="fa fa-image" style="color:#e94560;margin-right:6px"></i>Featured Image
        </div>

        <!-- Image preview box -->
        <div id="img-box" onclick="document.getElementById('feat-img-file').click()"
             style="width:100%;height:160px;border:2px dashed #e5e7eb;border-radius:10px;
                    display:flex;flex-direction:column;align-items:center;justify-content:center;
                    cursor:pointer;transition:.2s;overflow:hidden;position:relative;background:#f8f9fb">
          <!-- Placeholder -->
          <div id="img-placeholder" style="text-align:center;color:#9ca3af;pointer-events:none">
            <i class="fa fa-cloud-upload-alt" style="font-size:28px;display:block;margin-bottom:8px"></i>
            <div style="font-size:13px;font-weight:500">Click to upload featured image</div>
            <div style="font-size:11px;margin-top:4px">JPG, PNG, WebP · Max 5MB</div>
          </div>
          <!-- Preview (hidden until image selected) -->
          <img id="feat-img-preview" src="" alt=""
               style="display:none;width:100%;height:100%;object-fit:cover;position:absolute;top:0;left:0">
        </div>

        <input type="file" id="feat-img-file" accept="image/jpeg,image/png,image/webp,image/gif"
               style="display:none" onchange="onImageSelected(this)">

        <!-- Actions shown after image selected -->
        <div id="img-actions" style="display:none;margin-top:8px;display:none;align-items:center;justify-content:space-between">
          <span style="font-size:12px;color:#10b981;font-weight:500">
            <i class="fa fa-check-circle"></i> <span id="img-name">image.jpg</span>
          </span>
          <button class="btn-sec btn-sm-nf" style="font-size:12px" onclick="removeImage(event)">
            <i class="fa fa-times"></i> Remove
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- RIGHT: Site selector + publish button -->
  <div class="card">
    <div class="card-header"><i class="fa fa-globe" style="color:#3b82f6;margin-right:8px"></i>Select WordPress Sites</div>
    <div class="card-body" style="padding:14px">
      <?php if (empty($sites)): ?>
        <div style="text-align:center;padding:30px;color:var(--text2);font-size:13px">
          <i class="fa fa-globe" style="font-size:28px;display:block;margin-bottom:8px;color:#d1d5db"></i>
          No active WordPress sites.<br>
          <a href="wp-sites.php" style="color:#3b82f6">Add and activate a site first</a>
        </div>
      <?php else: ?>
        <?php
        $colors = ['#e94560','#3b82f6','#f59e0b','#10b981','#8b5cf6','#ef4444','#06b6d4'];
        $i = 0;
        foreach ($sites as $site):
        ?>
        <div class="site-sel" data-id="<?= (int)$site['id'] ?>" onclick="toggleSite(this)"
             style="display:flex;align-items:center;gap:12px;padding:11px 13px;border:1.5px solid var(--border);border-radius:8px;cursor:pointer;margin-bottom:8px;transition:.15s;user-select:none">
          <input type="checkbox" style="width:16px;height:16px;accent-color:#e94560;pointer-events:none" tabindex="-1">
          <div style="width:32px;height:32px;border-radius:7px;background:<?= $colors[$i % count($colors)] ?>;display:flex;align-items:center;justify-content:center;color:white;font-size:12px;flex-shrink:0">
            <i class="fa fa-globe"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-size:13.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($site['site_name']) ?></div>
            <div style="font-size:11px;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($site['site_url']) ?></div>
          </div>
        </div>
        <?php $i++; endforeach; ?>
        <div style="font-size:12px;color:#9ca3af;text-align:center;margin-top:4px">
          Click to select • Multiple sites supported
        </div>
      <?php endif; ?>
    </div>

    <div style="padding:16px;border-top:1px solid var(--border)">
      <button class="btn-primary-nf" style="width:100%;justify-content:center;font-size:14px"
              onclick="publishNow()" id="pub-btn">
        <i class="fa fa-paper-plane"></i> Publish Now
      </button>

      <!-- Live progress log -->
      <div id="pub-log" style="display:none;margin-top:16px"></div>
    </div>
  </div>

</div>

<!-- Publish history -->
<?php if (!empty($recentPubs)): ?>
<div class="card">
  <div class="card-header">Recent Published Articles</div>
  <div class="card-body" style="padding:0">
    <table class="data-table">
      <thead><tr><th>Article</th><th>Site</th><th>WP Post ID</th><th>Status</th><th>Published</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($recentPubs as $p): ?>
        <tr>
          <td style="font-size:13px;max-width:260px">
            <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
              <?= htmlspecialchars($p['seo_title'] ?: $p['title'] ?: 'Untitled') ?>
            </div>
          </td>
          <td style="font-size:13px"><?= htmlspecialchars($p['site_name']) ?></td>
          <td style="font-size:13px">#<?= (int)$p['wp_post_id'] ?></td>
          <td><span class="<?= $p['publish_status']==='publish'?'badge-suc':($p['publish_status']==='draft'?'badge-warn':'badge-info') ?>">
            <?= htmlspecialchars($p['publish_status']) ?></span></td>
          <td style="font-size:12px;color:#9ca3af"><?= date('d M Y H:i', strtotime($p['published_date'])) ?></td>
          <td>
            <a href="<?= htmlspecialchars($p['site_url']) ?>/?p=<?= (int)$p['wp_post_id'] ?>"
               target="_blank" class="btn-sec btn-sm-nf" title="View on WordPress">
              <i class="fa fa-external-link-alt"></i>
            </a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<script>
// ── Load article data from sessionStorage ─────────────────────
// Read at page load for the preview only
function getCurrentArticleId() {
  return sessionStorage.getItem('publishArticleId'); // always read fresh
}

(function initPreview() {
  const artData = sessionStorage.getItem('generatedArticle');
  const artId   = sessionStorage.getItem('publishArticleId');
  if (!artData || !artId) return;
  try {
    const d = JSON.parse(artData);
    document.getElementById('no-article').style.display       = 'none';
    document.getElementById('article-preview').style.display  = 'block';
    document.getElementById('pub-settings').style.display     = 'block';
    document.getElementById('pub-settings-img').style.display = 'block';
    document.getElementById('pub-title').textContent = d.seoTitle || 'Untitled Article';
    const tmp = document.createElement('div');
    tmp.innerHTML = d.body || '';
    document.getElementById('pub-body').textContent = (tmp.innerText || '').substring(0, 400) + '…';
    if (d.language)              document.getElementById('pub-lang').textContent   = '🌐 ' + d.language;
    if (d.ai_engine || d.engine) document.getElementById('pub-engine').textContent = '🤖 ' + (d.ai_engine || d.engine || 'Claude');
    if (d.tags)                  document.getElementById('pub-tags').textContent   = '🏷 ' + d.tags;
    document.getElementById('pub-title').insertAdjacentHTML('afterend',
      `<div style="font-size:11px;color:#9ca3af;margin-bottom:8px">Article ID: #${artId}</div>`);
  } catch(e) { console.error('Preview error', e); }
})();

// ── Featured image ────────────────────────────────────────────
let selectedImageBase64 = '';

// Check if editor passed an image
const editorImg = sessionStorage.getItem('editorImageBase64');
if (editorImg) {
  selectedImageBase64 = editorImg;
  // Show preview
  const preview = document.getElementById('feat-img-preview');
  preview.src = 'data:image/jpeg;base64,' + editorImg;
  preview.style.display = 'block';
  document.getElementById('img-placeholder').style.display = 'none';
  document.getElementById('img-box').style.borderColor = '#10b981';
  document.getElementById('img-box').style.borderStyle = 'solid';
  document.getElementById('img-name').textContent = 'Image from editor';
  document.getElementById('img-actions').style.display = 'flex';
  // Clear so it doesn't persist to next publish
  sessionStorage.removeItem('editorImageBase64');
}

function onImageSelected(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    showToast('Image too large — max 5MB', 'error');
    input.value = '';
    return;
  }
  const reader = new FileReader();
  reader.onload = e => {
    selectedImageBase64 = e.target.result.split(',')[1]; // base64 only
    // Show preview
    const preview = document.getElementById('feat-img-preview');
    preview.src   = e.target.result;
    preview.style.display = 'block';
    document.getElementById('img-placeholder').style.display = 'none';
    document.getElementById('img-box').style.borderColor = '#10b981';
    document.getElementById('img-box').style.borderStyle = 'solid';
    // Show filename + remove button
    document.getElementById('img-name').textContent = file.name;
    document.getElementById('img-actions').style.display = 'flex';
  };
  reader.readAsDataURL(file);
}

function removeImage(e) {
  e.stopPropagation();
  selectedImageBase64 = '';
  document.getElementById('feat-img-file').value = '';
  document.getElementById('feat-img-preview').style.display = 'none';
  document.getElementById('feat-img-preview').src = '';
  document.getElementById('img-placeholder').style.display = 'block';
  document.getElementById('img-box').style.borderColor = '#e5e7eb';
  document.getElementById('img-box').style.borderStyle = 'dashed';
  document.getElementById('img-actions').style.display = 'none';
}

// ── Toggle site selection ─────────────────────────────────────
function toggleSite(el) {
  el.classList.toggle('sel');
  const cb = el.querySelector('input[type=checkbox]');
  cb.checked = el.classList.contains('sel');
  el.style.borderColor = cb.checked ? '#e94560' : 'var(--border)';
  el.style.background  = cb.checked ? '#fff5f7' : 'white';
}

// ── Publish ───────────────────────────────────────────────────
async function publishNow() {
  const selEls  = [...document.querySelectorAll('.site-sel.sel')];
  const siteIds = selEls.map(e => parseInt(e.dataset.id));

  // Always read fresh from sessionStorage at click time — not from a stale variable
  const artId = getCurrentArticleId();

  if (!siteIds.length) { showToast('Select at least one WordPress site', 'error'); return; }
  if (!artId)          { showToast('No article loaded — please generate content first', 'error'); return; }

  const btn  = document.getElementById('pub-btn');
  const log  = document.getElementById('pub-log');
  btn.disabled = true;
  btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Publishing…';
  log.style.display = 'block';
  log.innerHTML = logLine('info', `Publishing article #${artId} to ${siteIds.length} site(s)…`);

  let respData;
  try {
    const resp = await fetch('api/publish.php', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        article_id:        parseInt(artId),
        site_ids:          siteIds,
        mode:              document.getElementById('pub-mode').value,
        schedule_at:       document.getElementById('pub-sched')?.value || '',
        manual_image_data: selectedImageBase64 || '',
      }),
    });
    respData = await resp.json();
  } catch (e) {
    log.innerHTML = logLine('error', 'Network error: ' + e.message);
    btn.disabled = false;
    btn.innerHTML = '<i class="fa fa-paper-plane"></i> Publish Now';
    return;
  }

  btn.disabled  = false;
  btn.innerHTML = '<i class="fa fa-paper-plane"></i> Publish Now';

  if (respData.error) {
    log.innerHTML = logLine('error', respData.error);
    showToast(respData.error, 'error');
    return;
  }

  // Render per-site results
  log.innerHTML = '';
  (respData.results || []).forEach(r => {
    const siteHead = `<div style="font-weight:600;font-size:13.5px;margin-bottom:6px;color:#1a1a2e">
      <i class="fa fa-globe" style="color:#3b82f6;margin-right:5px"></i>${r.site_name}</div>`;
    const stepLog = (r.log || []).map(l =>
      `<div style="font-size:12px;color:#6b7280;padding:2px 0 2px 18px">${l}</div>`
    ).join('');

    if (r.success) {
      const viewBtn = r.post_url
        ? `<a href="${r.post_url}" target="_blank" class="btn-sec btn-sm-nf" style="margin-top:8px;font-size:12px"><i class="fa fa-external-link-alt"></i> View Post</a>`
        : '';
      log.innerHTML += `
        <div style="border:1px solid #d1fae5;background:#f0fdf4;border-radius:8px;padding:12px 14px;margin-bottom:10px">
          ${siteHead}${stepLog}
          <div style="font-size:13px;color:#065f46;margin-top:6px">
            <i class="fa fa-check-circle"></i>
            Published! WordPress Post ID: <strong>#${r.wp_post_id}</strong>
          </div>
          ${viewBtn}
        </div>`;
    } else {
      log.innerHTML += `
        <div style="border:1px solid #fca5a5;background:#fef2f2;border-radius:8px;padding:12px 14px;margin-bottom:10px">
          ${siteHead}${stepLog}
          <div style="font-size:13px;color:#991b1b;margin-top:6px">
            <i class="fa fa-times-circle"></i> <strong>Failed:</strong> ${r.error}
          </div>
          <div style="font-size:12px;color:#6b7280;margin-top:6px">
            Check <a href="wp-sites.php" style="color:#3b82f6">WordPress Sites</a> settings and try again.
          </div>
        </div>`;
    }
  });

  const okCount = respData.success_count || 0;
  const total   = respData.total || 0;

  if (okCount > 0) {
    showToast(`Published to ${okCount} of ${total} site(s)!`, 'success');
    // ── Clear sessionStorage after successful publish ──────────
    // This prevents the old article from being re-published on refresh
    if (okCount === total) {
      sessionStorage.removeItem('publishArticleId');
      sessionStorage.removeItem('generatedArticle');
      sessionStorage.removeItem('selectedArticle');
      sessionStorage.removeItem('editorContent');
      // Update preview to show "published" state
      document.getElementById('pub-title').style.color = '#10b981';
      const badge = document.createElement('div');
      badge.style.cssText = 'background:#d1fae5;color:#065f46;padding:8px 14px;border-radius:8px;font-size:13px;margin-top:10px;font-weight:500';
      badge.innerHTML = '<i class="fa fa-check-circle" style="margin-right:6px"></i>Published successfully! <a href="news-search.php" style="color:#065f46;font-weight:700;margin-left:8px">Search new articles →</a>';
      document.getElementById('pub-body').parentNode.appendChild(badge);
      // Reload after 4s to refresh the history table and reset the page
      setTimeout(() => location.reload(), 4000);
    }
  } else {
    showToast('Publishing failed — see details above', 'error');
  }
}

function logLine(type, msg) {
  const color = type === 'error' ? '#991b1b' : type === 'success' ? '#065f46' : '#1e40af';
  const icon  = type === 'error' ? 'fa-times-circle' : type === 'success' ? 'fa-check-circle' : 'fa-info-circle';
  const bg    = type === 'error' ? '#fef2f2' : type === 'success' ? '#f0fdf4' : '#eff6ff';
  return `<div style="background:${bg};border-radius:6px;padding:10px 14px;font-size:13px;color:${color}">
    <i class="fa ${icon}" style="margin-right:6px"></i>${msg}</div>`;
}
</script>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>

<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$pageTitle  = 'Dashboard';
$activePage = 'dashboard';

// Stats
$totalPublishers = Database::query("SELECT COUNT(*) c FROM users WHERE role='publisher'")->fetch()['c'];
$totalSites      = Database::query("SELECT COUNT(*) c FROM wordpress_sites WHERE status='active'")->fetch()['c'];
$generatedToday  = Database::query("SELECT COUNT(*) c FROM articles WHERE DATE(created_date)=CURDATE()")->fetch()['c'];
$publishedToday  = Database::query("SELECT COUNT(*) c FROM published_posts WHERE DATE(published_date)=CURDATE()")->fetch()['c'];
$recentLogs      = Database::query("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 8")->fetchAll();
$recentArticles  = Database::query("SELECT a.*,u.fullname FROM articles a LEFT JOIN users u ON a.created_by=u.id ORDER BY a.id DESC LIMIT 5")->fetchAll();

include __DIR__ . '/includes/layout.php';
?>

<div class="grid-4" style="margin-bottom:24px">
  <div class="card" style="padding:20px;display:flex;align-items:center;gap:16px">
    <div style="width:46px;height:46px;border-radius:10px;background:#fff5f7;display:flex;align-items:center;justify-content:center;font-size:18px;color:#e94560"><i class="fa fa-users"></i></div>
    <div><div style="font-size:26px;font-weight:700"><?= $totalPublishers ?></div><div style="font-size:12px;color:var(--text2)">Total Publishers</div></div>
  </div>
  <div class="card" style="padding:20px;display:flex;align-items:center;gap:16px">
    <div style="width:46px;height:46px;border-radius:10px;background:#eff6ff;display:flex;align-items:center;justify-content:center;font-size:18px;color:#3b82f6"><i class="fa fa-globe"></i></div>
    <div><div style="font-size:26px;font-weight:700"><?= $totalSites ?></div><div style="font-size:12px;color:var(--text2)">Active WP Sites</div></div>
  </div>
  <div class="card" style="padding:20px;display:flex;align-items:center;gap:16px">
    <div style="width:46px;height:46px;border-radius:10px;background:#f0fdf4;display:flex;align-items:center;justify-content:center;font-size:18px;color:#10b981"><i class="fa fa-magic"></i></div>
    <div><div style="font-size:26px;font-weight:700"><?= $generatedToday ?></div><div style="font-size:12px;color:var(--text2)">Generated Today</div></div>
  </div>
  <div class="card" style="padding:20px;display:flex;align-items:center;gap:16px">
    <div style="width:46px;height:46px;border-radius:10px;background:#fffbeb;display:flex;align-items:center;justify-content:center;font-size:18px;color:#f59e0b"><i class="fa fa-paper-plane"></i></div>
    <div><div style="font-size:26px;font-weight:700"><?= $publishedToday ?></div><div style="font-size:12px;color:var(--text2)">Published Today</div></div>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-header">Recent Activity</div>
    <div class="card-body" style="padding:0">
      <?php if (empty($recentLogs)): ?>
        <div style="padding:30px;text-align:center;color:var(--text2);font-size:13px">No activity yet</div>
      <?php else: ?>
        <?php foreach ($recentLogs as $log): ?>
          <div style="display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border)">
            <div style="width:32px;height:32px;border-radius:8px;background:#f1f3f7;display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0;color:#6b7280">
              <i class="fa <?= $log['action']==='Login'?'fa-sign-in-alt':($log['action']==='Publish'?'fa-paper-plane':'fa-magic') ?>"></i>
            </div>
            <div>
              <div style="font-size:12px;color:#9ca3af"><?= date('d M H:i', strtotime($log['created_date'])) ?> — <strong><?= htmlspecialchars($log['username']) ?></strong></div>
              <div style="font-size:13px"><?= htmlspecialchars($log['description']) ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
  <div class="card">
    <div class="card-header">Recent Articles</div>
    <div class="card-body" style="padding:0">
      <?php if (empty($recentArticles)): ?>
        <div style="padding:30px;text-align:center;color:var(--text2);font-size:13px">No articles yet — <a href="news-search.php">search for news</a></div>
      <?php else: ?>
        <?php foreach ($recentArticles as $art): ?>
          <div style="padding:12px 16px;border-bottom:1px solid var(--border)">
            <div style="font-size:13.5px;font-weight:600;margin-bottom:3px"><?= htmlspecialchars(substr($art['title'],0,60)) ?>...</div>
            <div style="display:flex;align-items:center;gap:8px">
              <span class="badge-<?= $art['status']==='published'?'suc':($art['status']==='ready'?'info':'gray') ?>"><?= $art['status'] ?></span>
              <span style="font-size:11px;color:#9ca3af"><?= $art['ai_engine'] ?> · <?= $art['language'] ?></span>
              <span style="font-size:11px;color:#9ca3af;margin-left:auto"><?= date('d M', strtotime($art['created_date'])) ?></span>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>

<?php
// change-password.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$cu=current_user();
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['change_pass'])){
    $cur=$_POST['current_pass']??'';$new=$_POST['new_pass']??'';$conf=$_POST['confirm_pass']??'';
    $row=Database::query("SELECT password FROM users WHERE id=?",[$cu['id']])->fetch();
    if(!password_verify($cur,$row['password']))$err='Current password incorrect';
    elseif(strlen($new)<8)$err='Password must be at least 8 characters';
    elseif($new!==$conf)$err='Passwords do not match';
    else{Database::query("UPDATE users SET password=? WHERE id=?",[ password_hash($new,PASSWORD_BCRYPT),$cu['id']]);log_activity('Password Change','Changed password');$msg='Password updated successfully!';}
}
$pageTitle='Change Password';$activePage='change-password';
include __DIR__.'/includes/layout.php';
?>
<div style="max-width:480px">
  <div class="card">
    <div class="card-header"><i class="fa fa-lock" style="color:#e94560;margin-right:8px"></i>Change Password</div>
    <div class="card-body">
      <?php if(isset($msg)):?><div style="background:#d1fae5;color:#065f46;padding:10px 14px;border-radius:8px;margin-bottom:16px;font-size:13.5px"><i class="fa fa-check-circle" style="margin-right:6px"></i><?=htmlspecialchars($msg)?></div><?php endif;?>
      <?php if(isset($err)):?><div style="background:#fee2e2;color:#991b1b;padding:10px 14px;border-radius:8px;margin-bottom:16px;font-size:13.5px"><i class="fa fa-exclamation-circle" style="margin-right:6px"></i><?=htmlspecialchars($err)?></div><?php endif;?>
      <form method="POST">
        <div class="form-group"><label>Current Password</label><input type="password" name="current_pass" class="inp" required placeholder="Enter current password"></div>
        <div class="form-group"><label>New Password</label><input type="password" name="new_pass" class="inp" required placeholder="Min 8 characters"></div>
        <div class="form-group"><label>Confirm New Password</label><input type="password" name="confirm_pass" class="inp" required placeholder="Repeat new password"></div>
        <div style="background:#f8f9fb;border-radius:8px;padding:12px;margin-bottom:16px;font-size:12.5px;color:var(--text2)">
          <div style="font-weight:600;margin-bottom:5px;color:#1a1a2e">Requirements:</div>
          <div>• Minimum 8 characters</div><div>• Mix of letters and numbers recommended</div>
        </div>
        <button type="submit" name="change_pass" class="btn-primary-nf"><i class="fa fa-lock"></i> Update Password</button>
      </form>
    </div>
  </div>
</div>
<?php require __DIR__.'/includes/layout_footer.php'; ?>

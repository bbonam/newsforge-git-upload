<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
header('Content-Type: application/json');

$input      = json_decode(file_get_contents('php://input'), true) ?? [];
$siteIds    = $input['site_ids']    ?? [];
$articleId  = (int)($input['article_id'] ?? 0);
$pubMode    = $input['mode']        ?? 'publish';
$scheduleAt = $input['schedule_at'] ?? null;
$manualImg  = trim($input['manual_image_data'] ?? ''); // base64 from manual upload

if (empty($siteIds)) { echo json_encode(['error' => 'No WordPress sites selected']); exit; }
if (!$articleId)     { echo json_encode(['error' => 'No article ID — generate content first']); exit; }

$article = Database::query("SELECT * FROM articles WHERE id=?", [$articleId])->fetch();
if (!$article) { echo json_encode(['error' => "Article #$articleId not found"]); exit; }

$postTitle   = trim($article['seo_title']         ?: $article['title']  ?: 'Untitled Article');
$postContent = trim($article['generated_content'] ?: '');
$postExcerpt = trim($article['meta_description']  ?: '');
$postTags    = trim($article['tags']              ?: '');

if (!$postContent) { echo json_encode(['error' => 'Article has no content — please regenerate']); exit; }

// ── Download remote image → return raw binary string ─────────
function downloadImage(string $url): string {
    if (!$url || str_starts_with($url, 'data:')) return '';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; NewsForge/1.0)',
    ]);
    $data = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($code === 200 && strlen($data) > 2000) ? $data : '';
}

// ── Single cURL helper ────────────────────────────────────────
function nfCurl(string $method, string $url, array $headers, ?string $body, int $timeout = 20): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_USERAGENT      => 'NewsForge/1.0',
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($body) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    $resp    = curl_exec($ch);
    $code    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);
    return ['code' => $code, 'body' => json_decode($resp, true), 'raw' => $resp, 'err' => $curlErr];
}

// ── Upload raw image bytes to WP media via REST API ───────────
function uploadImageToWP(string $imgData, string $filename, string $endpoint, string $wpUser, string $wpPass): ?int {
    if (!$imgData || strlen($imgData) < 1000) return null;

    $ext      = strtolower(pathinfo($filename, PATHINFO_EXTENSION)) ?: 'jpg';
    $mimeType = match($ext) {
        'png'  => 'image/png',
        'gif'  => 'image/gif',
        'webp' => 'image/webp',
        default => 'image/jpeg',
    };
    $auth = base64_encode("$wpUser:$wpPass");

    // Strategy 1: Authorization header
    $ch = curl_init("$endpoint/media");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_USERAGENT      => 'NewsForge/1.0',
        CURLOPT_HTTPHEADER     => [
            'Authorization: Basic ' . $auth,
            'Content-Type: ' . $mimeType,
            'Content-Disposition: attachment; filename="' . $filename . '"',
            'Accept: application/json',
        ],
        CURLOPT_POSTFIELDS => $imgData,
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $body = json_decode($resp, true);
    if (in_array($code, [200, 201]) && !empty($body['id'])) return (int)$body['id'];

    // Strategy 2: Credentials in URL (Hostinger fix)
    $urlWithCreds = str_replace('://', '://' . rawurlencode($wpUser) . ':' . rawurlencode($wpPass) . '@', "$endpoint/media");
    $ch = curl_init($urlWithCreds);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_USERAGENT      => 'NewsForge/1.0',
        CURLOPT_HTTPHEADER     => [
            'Content-Type: ' . $mimeType,
            'Content-Disposition: attachment; filename="' . $filename . '"',
            'Accept: application/json',
        ],
        CURLOPT_POSTFIELDS => $imgData,
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $body = json_decode($resp, true);
    if (in_array($code, [200, 201]) && !empty($body['id'])) return (int)$body['id'];

    return null;
}

// ── Publish via NewsForge Plugin ──────────────────────────────
function publishViaPlugin(string $siteUrl, string $secretKey, array $payload): array {
    $endpoint = rtrim($siteUrl, '/') . '/wp-json/newsforge/v1/publish';
    $result   = nfCurl('POST', $endpoint,
        ['Content-Type: application/json', 'X-NewsForge-Key: ' . $secretKey],
        json_encode($payload), 45
    );
    if ($result['err'])          return ['ok' => false, 'error' => 'Connection error: ' . $result['err']];
    if ($result['code'] === 404) return ['ok' => false, 'error' => 'plugin_not_found'];
    if ($result['code'] === 403) return ['ok' => false, 'error' => 'Invalid secret key'];
    if (in_array($result['code'], [200, 201]) && !empty($result['body']['post_id'])) {
        return ['ok' => true, 'data' => $result['body']];
    }
    $msg = $result['body']['error'] ?? $result['body']['message'] ?? ('HTTP ' . $result['code']);
    return ['ok' => false, 'error' => $msg];
}

// ── Publish via WP REST API ───────────────────────────────────
function publishViaRestAPI(string $siteUrl, string $wpUser, string $wpPass,
                            array $payload, string $category, string $tags, ?int $mediaId): array {
    $endpoint = rtrim($siteUrl, '/') . '/wp-json/wp/v2';
    $auth     = base64_encode("$wpUser:$wpPass");

    $categoryId = null;
    if ($category) {
        $r = nfCurl('GET', "$endpoint/categories?search=" . urlencode($category) . "&per_page=1",
            ['Authorization: Basic ' . $auth], null, 10);
        if (!empty($r['body'][0]['id'])) {
            $categoryId = $r['body'][0]['id'];
        } else {
            $c = nfCurl('POST', "$endpoint/categories",
                ['Authorization: Basic ' . $auth, 'Content-Type: application/json'],
                json_encode(['name' => $category]), 10);
            if (!empty($c['body']['id'])) $categoryId = $c['body']['id'];
        }
    }

    $tagIds = [];
    foreach (array_slice(array_map('trim', explode(',', $tags)), 0, 5) as $tag) {
        if (!$tag) continue;
        $r = nfCurl('GET', "$endpoint/tags?search=" . urlencode($tag) . "&per_page=1",
            ['Authorization: Basic ' . $auth], null, 8);
        if (!empty($r['body'][0]['id'])) { $tagIds[] = $r['body'][0]['id']; continue; }
        $c = nfCurl('POST', "$endpoint/tags",
            ['Authorization: Basic ' . $auth, 'Content-Type: application/json'],
            json_encode(['name' => $tag]), 8);
        if (!empty($c['body']['id'])) $tagIds[] = $c['body']['id'];
    }

    $postData = [
        'title'   => $payload['title'],
        'content' => $payload['content'],
        'excerpt' => $payload['excerpt'],
        'status'  => $payload['status'],
        'format'  => 'standard',
    ];
    if ($categoryId)     $postData['categories']    = [$categoryId];
    if (!empty($tagIds)) $postData['tags']           = $tagIds;
    if ($mediaId)        $postData['featured_media'] = $mediaId;
    if ($payload['status'] === 'future' && !empty($payload['schedule_at'])) {
        $postData['date'] = date('Y-m-d\TH:i:s', strtotime($payload['schedule_at']));
    }

    $r = nfCurl('POST', "$endpoint/posts",
        ['Authorization: Basic ' . $auth, 'Content-Type: application/json'],
        json_encode($postData), 30);
    if ($r['code'] === 401) {
        $p = parse_url("$endpoint/posts");
        $u = ($p['scheme'] ?? 'https') . '://' . rawurlencode($wpUser) . ':' . rawurlencode($wpPass)
           . '@' . $p['host'] . $p['path'];
        $r = nfCurl('POST', $u, ['Content-Type: application/json'], json_encode($postData), 30);
    }
    if ($r['err']) return ['ok' => false, 'error' => 'Connection error: ' . $r['err']];
    if (in_array($r['code'], [200, 201]) && !empty($r['body']['id'])) {
        return ['ok' => true, 'data' => ['post_id' => $r['body']['id'], 'post_url' => $r['body']['link'] ?? '']];
    }
    if ($r['code'] === 401) return ['ok' => false, 'error' => 'rest_401'];
    return ['ok' => false, 'error' => $r['body']['message'] ?? ('HTTP ' . $r['code'])];
}

// ─────────────────────────────────────────────────────────────
// MAIN: Download image ONCE, save locally, reuse URL for all sites
// ─────────────────────────────────────────────────────────────
$imgData     = '';
$imgFilename = 'featured-' . $articleId . '.jpg';
$imgLocalUrl = '';  // public URL on NewsForge server
$imgSource   = '';

$uploadDir = rtrim(UPLOAD_DIR, '/') . '/';
if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);

if ($manualImg) {
    // Manual upload from publish page (base64)
    $imgData   = base64_decode($manualImg);
    $imgSource = 'manual upload';
} else {
    // Auto: download from stored image_url
    $rawUrl = trim($article['image_url'] ?? '');
    if ($rawUrl && !str_starts_with($rawUrl, 'data:')) {
        $imgData   = downloadImage($rawUrl);
        $imgSource = 'auto downloaded';
        $ext = strtolower(pathinfo(parse_url($rawUrl, PHP_URL_PATH), PATHINFO_EXTENSION));
        if (in_array($ext, ['png','gif','webp'])) {
            $imgFilename = 'featured-' . $articleId . '.' . $ext;
        }
    }
}

// Save to local uploads so WordPress can fetch via stable URL
if ($imgData && strlen($imgData) > 2000) {
    $localPath = $uploadDir . $imgFilename;
    if (file_put_contents($localPath, $imgData)) {
        $imgLocalUrl = rtrim(APP_URL, '/') . '/uploads/images/' . $imgFilename;
    }
}

// ─────────────────────────────────────────────────────────────
// Process each site
// ─────────────────────────────────────────────────────────────
$results = [];

foreach ($siteIds as $siteId) {
    $siteId = (int)$siteId;
    $site   = Database::query("SELECT * FROM wordpress_sites WHERE id=? AND status='active'", [$siteId])->fetch();
    if (!$site) {
        $results[] = ['site_id' => $siteId, 'site_name' => "Site #$siteId",
                      'success' => false, 'error' => 'Site not found or inactive'];
        continue;
    }

    $siteName  = $site['site_name'];
    $siteUrl   = rtrim($site['site_url'], '/');
    $secretKey = trim($site['secret_key'] ?? '');
    $wpUser    = $site['wp_username'];
    $wpPass    = $site['wp_password'];
    $log       = [];

    $wpStatus = match($pubMode) {
        'draft'    => 'draft',
        'schedule' => 'future',
        default    => 'publish',
    };

    if ($imgLocalUrl) {
        $log[] = "✓ Image ready ($imgSource, " . round(strlen($imgData) / 1024) . " KB) → " . $imgFilename;
    } elseif ($imgData) {
        $log[] = "⚠ Image downloaded but could not save locally — will try direct upload";
    } else {
        $log[] = "ℹ No featured image";
    }

    $payload = [
        'title'       => $postTitle,
        'content'     => $postContent,
        'excerpt'     => $postExcerpt,
        'status'      => $wpStatus,
        'category'    => $site['default_category'] ?? '',
        'tags'        => $postTags,
        'seo_title'   => $postTitle,
        'meta_desc'   => $postExcerpt,
        'schedule_at' => $scheduleAt,
        // Pass stable local URL — plugin fetches from NewsForge server
        // No base64 bloat, no expired external URLs
        'image_url'      => $imgLocalUrl,
        'image_filename' => $imgFilename,
    ];

    $published = false;
    $postId    = null;
    $postUrl   = '';

    // ── Method 1: NewsForge Plugin ────────────────────────────
    if ($secretKey) {
        $log[] = "Trying NewsForge Plugin...";
        $r = publishViaPlugin($siteUrl, $secretKey, $payload);
        if ($r['ok']) {
            $published = true;
            $postId    = $r['data']['post_id'];
            $postUrl   = $r['data']['post_url'] ?? '';
            $log[]     = "✓ Published via plugin (post ID: $postId)";
            if (!empty($r['data']['image'])) $log[] = "✓ Featured image set";
            elseif ($imgLocalUrl)            $log[] = "⚠ Post published — check featured image in WP";
        } elseif ($r['error'] === 'plugin_not_found') {
            $log[] = "⚠ Plugin not found — trying REST API";
        } else {
            $log[] = "✗ Plugin: " . $r['error'];
        }
    }

    // ── Method 2: WP REST API ─────────────────────────────────
    if (!$published && ($wpUser || $wpPass)) {
        $log[] = "Trying REST API...";
        $ping = nfCurl('GET', "$siteUrl/wp-json/", [], null, 10);
        if ($ping['err']) {
            $log[] = "✗ Cannot reach $siteUrl";
        } else {
            $log[] = "✓ REST API reachable";
            $mediaId = null;
            // Use raw binary data for direct upload to WP media
            if ($imgData && strlen($imgData) > 2000) {
                $endpoint = "$siteUrl/wp-json/wp/v2";
                $mediaId  = uploadImageToWP($imgData, $imgFilename, $endpoint, $wpUser, $wpPass);
                $log[]    = $mediaId
                    ? "✓ Featured image uploaded (media ID: $mediaId)"
                    : "⚠ Image upload failed — publishing without image";
            }
            $r = publishViaRestAPI($siteUrl, $wpUser, $wpPass, $payload,
                                   $site['default_category'] ?? '', $postTags, $mediaId);
            if ($r['ok']) {
                $published = true;
                $postId    = $r['data']['post_id'];
                $postUrl   = $r['data']['post_url'] ?? '';
                $log[]     = "✓ Published via REST API (post ID: $postId)";
            } elseif ($r['error'] === 'rest_401') {
                $log[] = "✗ Auth failed — install NewsForge Publisher plugin";
            } else {
                $log[] = "✗ " . $r['error'];
            }
        }
    }

    if (!$published) {
        $results[] = ['site_id' => $siteId, 'site_name' => $siteName, 'success' => false,
                      'error' => end($log) ?: 'All methods failed', 'log' => $log];
        log_activity('Publish Failed', "Failed → $siteName: " . (end($log) ?: 'unknown'));
        continue;
    }

    Database::reconnect();
    Database::query("INSERT INTO published_posts (article_id,site_id,wp_post_id,publish_status) VALUES (?,?,?,?)",
        [$articleId, $siteId, $postId, $wpStatus]);
    Database::query("UPDATE articles SET status='published' WHERE id=?", [$articleId]);
    log_activity('Publish', "Published #$articleId → $siteName (WP #$postId, $wpStatus)");

    $results[] = ['site_id' => $siteId, 'site_name' => $siteName, 'success' => true,
                  'wp_post_id' => $postId, 'post_url' => $postUrl, 'wp_status' => $wpStatus, 'log' => $log];
}

$ok = count(array_filter($results, fn($r) => $r['success']));
echo json_encode(['success' => true, 'results' => $results, 'success_count' => $ok, 'total' => count($results)]);

<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

header('Content-Type: application/json');

$input  = json_decode(file_get_contents('php://input'), true);
$engine = $input['engine']      ?? 'claude';
$title  = strip_tags($input['title']   ?? '');
$content= strip_tags($input['content'] ?? '');
$lang   = $input['language']   ?? 'English';
$style  = $input['style']      ?? 'rewrite';
$extra  = strip_tags($input['extra']   ?? '');

if (!$title && !$content) {
    echo json_encode(['error' => 'No article content provided']);
    exit;
}

$styleMap = [
    'rewrite'   => 'Rewrite this in authentic Telugu news journalistic style — concise, factual, structured.',
    'seo'       => 'Write an SEO-optimized article. Use keyword-rich H2/H3 headers, include relevant search terms naturally.',
    'humanized' => 'Write in an engaging, humanized style. Use storytelling, relatable language, and emotional connection.',
    'longform'  => 'Write a comprehensive long-form article with background context, multiple perspectives, data points, and expert analysis.',
    'summary'   => 'Write a crisp news summary in 3-4 focused paragraphs covering only the essential facts.',
];

$styleInstruction = $styleMap[$style] ?? $styleMap['rewrite'];
if ($extra) $styleInstruction .= " Additional: $extra";

$systemPrompt = "You are a professional " . ($lang === 'Telugu' ? 'Telugu-language' : 'English') .
    " news journalist for a leading Indian digital news platform covering Andhra Pradesh and Telangana. " .
    ($lang === 'Telugu' ? "Write all content in Telugu script using proper Telugu grammar and vocabulary." :
     "Write in clear, professional, journalistic English.") .
    " Always respond with valid JSON only — no markdown, no backticks, no preamble.";

$userPrompt = "$styleInstruction\n\nSource Article:\nTitle: $title\nContent: $content\n\n" .
    "Respond ONLY with this JSON structure:\n" .
    '{"seoTitle":"...","metaDescription":"160-char description","body":"full HTML with <p><h2><h3> tags","tags":"tag1,tag2,tag3,tag4,tag5"}';

// Resolve API key (config.php first, DB fallback)
function resolve_key(string $provider): string {
    $constMap = [
        'claude' => ANTHROPIC_API_KEY,
        'openai' => OPENAI_API_KEY,
        'gemini' => GEMINI_API_KEY,
    ];
    $fromConst = $constMap[$provider] ?? '';
    if ($fromConst && !str_contains($fromConst, 'YOUR_')) return $fromConst;

    // Try DB
    $row = Database::query("SELECT api_key FROM api_settings WHERE provider_name=?", [$provider])->fetch();
    if ($row && $row['api_key']) {
        try { return decrypt_key($row['api_key']); } catch(Exception $e) { return $row['api_key']; }
    }
    return '';
}

$result = [];

try {
    switch ($engine) {

        // ── CLAUDE ────────────────────────────────────────────
        case 'claude':
            $key = resolve_key('claude');
            if (!$key) { echo json_encode(['error' => 'Anthropic API key not configured']); exit; }

            $ch = curl_init('https://api.anthropic.com/v1/messages');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    'x-api-key: ' . $key,
                    'anthropic-version: 2023-06-01',
                ],
                CURLOPT_POSTFIELDS => json_encode([
                    'model'      => ANTHROPIC_MODEL,
                    'max_tokens' => 2000,
                    'system'     => $systemPrompt,
                    'messages'   => [['role' => 'user', 'content' => $userPrompt]],
                ]),
                CURLOPT_TIMEOUT        => 90,   // Claude can take 20-30s; allow up to 90s
                CURLOPT_CONNECTTIMEOUT => 10,
            ]);
            $resp = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode !== 200) {
                $err = json_decode($resp, true);
                echo json_encode(['error' => $err['error']['message'] ?? 'Claude API error (HTTP '.$httpCode.')']);
                exit;
            }
            $data = json_decode($resp, true);
            $text = $data['content'][0]['text'] ?? '';
            break;

        // ── OPENAI ────────────────────────────────────────────
        case 'openai':
            $key = resolve_key('openai');
            if (!$key) { echo json_encode(['error' => 'OpenAI API key not configured']); exit; }

            $ch = curl_init('https://api.openai.com/v1/chat/completions');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $key,
                ],
                CURLOPT_POSTFIELDS => json_encode([
                    'model'    => OPENAI_MODEL,
                    'messages' => [
                        ['role' => 'system', 'content' => $systemPrompt],
                        ['role' => 'user',   'content' => $userPrompt],
                    ],
                    'max_tokens'      => 2000,
                    'response_format' => ['type' => 'json_object'],
                ]),
                CURLOPT_TIMEOUT => 60,
            ]);
            $resp = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode !== 200) {
                $err = json_decode($resp, true);
                echo json_encode(['error' => $err['error']['message'] ?? 'OpenAI API error']);
                exit;
            }
            $data = json_decode($resp, true);
            $text = $data['choices'][0]['message']['content'] ?? '';
            break;

        // ── GEMINI ────────────────────────────────────────────
        case 'gemini':
            $key = resolve_key('gemini');
            if (!$key) { echo json_encode(['error' => 'Gemini API key not configured']); exit; }

            $url = "https://generativelanguage.googleapis.com/v1beta/models/" . GEMINI_MODEL . ":generateContent?key=$key";
            $ch  = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
                CURLOPT_POSTFIELDS     => json_encode([
                    'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
                    'contents'           => [['parts' => [['text' => $userPrompt]]]],
                    'generationConfig'   => ['responseMimeType' => 'application/json'],
                ]),
                CURLOPT_TIMEOUT => 60,
            ]);
            $resp = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode !== 200) {
                $err = json_decode($resp, true);
                echo json_encode(['error' => $err['error']['message'] ?? 'Gemini API error']);
                exit;
            }
            $data = json_decode($resp, true);
            $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
            break;

        default:
            echo json_encode(['error' => 'Unknown AI engine']);
            exit;
    }

    // Parse JSON response
    $text = trim(preg_replace('/^```json\s*|\s*```$/s', '', $text));
    $parsed = json_decode($text, true);

    if (!$parsed) {
        $parsed = [
            'seoTitle'        => $title,
            'metaDescription' => substr(strip_tags($text), 0, 160),
            'body'            => '<p>' . nl2br(htmlspecialchars($text)) . '</p>',
            'tags'            => 'Andhra Pradesh,Telangana,News',
        ];
    }

    // ── Image Generation ──────────────────────────────────────
    // Use image passed from news scraping first
    $imageUrl = trim($input['imageUrl'] ?? $input['image_url'] ?? '');

    // If no scraped image, try to generate/fetch one based on engine
    if (!$imageUrl) {
        $imageTitle = $parsed['seoTitle'] ?? $title;

        if ($engine === 'openai') {
            // ── DALL-E 3: generate image when using OpenAI ────
            $imageUrl = generate_dalle_image($imageTitle, resolve_key('openai'));
        }

        // For Claude, Gemini, or if DALL-E failed → try Unsplash
        if (!$imageUrl) {
            $imageUrl = fetch_unsplash_image($imageTitle);
        }
    }

    // ── Reconnect + Save to DB ────────────────────────────────
    Database::reconnect();
    $user = current_user();

    Database::query(
        "INSERT INTO articles (title,seo_title,meta_description,generated_content,image_url,language,ai_engine,source_url,tags,status,created_by)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        [
            $title,
            $parsed['seoTitle']        ?? $title,
            $parsed['metaDescription'] ?? '',
            $parsed['body']            ?? '',
            $imageUrl,
            $lang,
            $engine,
            $input['sourceUrl'] ?? '',
            $parsed['tags']     ?? '',
            'ready',
            $user['id'],
        ]
    );
    $articleId = Database::connect()->lastInsertId();

    log_activity('AI Generate', "Generated $lang content via $engine for: \"$title\"" . ($imageUrl ? ' [image attached]' : ''));

    echo json_encode([
        'success'    => true,
        'article_id' => $articleId,
        'image_url'  => $imageUrl,
        'data'       => array_merge($parsed, ['image_url' => $imageUrl]),
    ]);

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

// ── DALL-E 3 Image Generator ──────────────────────────────────
function generate_dalle_image(string $title, string $apiKey): string {
    if (!$apiKey || str_contains($apiKey, 'YOUR_')) return '';

    // Build a news-photo style prompt from the title
    // Keep it clean — no faces, no text in image (avoids DALL-E refusals)
    $prompt = "Professional news photograph illustrating: {$title}. "
            . "Photorealistic, high quality, journalistic style, no text or watermarks, "
            . "no faces visible, suitable for Indian regional news publication.";

    $ch = curl_init('https://api.openai.com/v1/images/generations');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
        ],
        CURLOPT_POSTFIELDS => json_encode([
            'model'           => 'dall-e-3',
            'prompt'          => $prompt,
            'n'               => 1,
            'size'            => '1792x1024',  // best landscape ratio for featured images
            'quality'         => 'standard',   // 'hd' costs 2x — standard is fine for news
            'response_format' => 'url',
        ]),
    ]);
    $resp     = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) return '';

    $data = json_decode($resp, true);
    return $data['data'][0]['url'] ?? '';
}

// ── Unsplash Image Fetcher (free fallback for Claude/Gemini) ──
function fetch_unsplash_image(string $title): string {
    $accessKey = defined('UNSPLASH_ACCESS_KEY') ? UNSPLASH_ACCESS_KEY : '';
    if (!$accessKey || str_contains($accessKey, 'YOUR_')) return '';

    // Extract meaningful keywords — remove stop words
    $stopWords = ['the','a','an','is','are','was','were','in','on','at','of','and','or','for',
                  'to','with','by','from','that','this','it','as','be','has','have','had',
                  'latest','update','report','news','today','says','తెలంగాణ','ఆంధ్రప్రదేశ్'];
    $words = preg_split('/[\s,;:—–\-]+/', strtolower($title));
    $keywords = array_filter($words, fn($w) => strlen($w) > 3 && !in_array($w, $stopWords));
    $query = implode(' ', array_slice(array_values($keywords), 0, 4));
    if (!$query) $query = 'India news';

    $url = 'https://api.unsplash.com/search/photos?' . http_build_query([
        'query'       => $query,
        'per_page'    => 5,
        'orientation' => 'landscape',
        'content_filter' => 'high',
    ]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Client-ID ' . $accessKey,
            'Accept-Version: v1',
        ],
    ]);
    $resp     = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) return '';

    $data    = json_decode($resp, true);
    $results = $data['results'] ?? [];
    if (empty($results)) return '';

    // Pick a random one from top 5 so articles don't always look the same
    $pick = $results[array_rand($results)];
    // Use regular size (1080px wide) — good quality, not too heavy
    return $pick['urls']['regular'] ?? $pick['urls']['full'] ?? '';
}

<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
header('Content-Type: application/json');

$category = htmlspecialchars($_GET['category'] ?? 'Andhra Pradesh');
$keywords  = htmlspecialchars($_GET['keywords'] ?? '');
$source    = $_GET['source'] ?? 'newsapi'; // newsapi | rss | both
$query     = trim("$category $keywords");

log_activity('News Search', "Searched: \"$query\" via $source");

$articles = [];
$usedSource = '';

// ── Resolve NewsAPI key: config.php first, then DB ────────────
function getNewsApiKey(): string {
    // 1. config.php
    $fromConfig = defined('NEWSAPI_KEY') ? NEWSAPI_KEY : '';
    if ($fromConfig && strlen($fromConfig) > 10 && !str_contains($fromConfig, 'YOUR_')) {
        return $fromConfig;
    }
    // 2. DB api_settings table
    try {
        $row = Database::query(
            "SELECT api_key FROM api_settings WHERE provider_name='newsapi' AND status='active'"
        )->fetch();
        if ($row && !empty($row['api_key'])) {
            // Try decrypt, fallback to raw
            try { return decrypt_key($row['api_key']); } catch(Exception $e) { return $row['api_key']; }
        }
    } catch (Exception $e) {}
    return '';
}

// ── Helper: scrape OG image from article URL ──────────────────
function scrapeOgImage(string $url): string {
    if (!$url) return '';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; NewsForge/1.0)',
        CURLOPT_RANGE          => '0-40000',
    ]);
    $html = curl_exec($ch);
    curl_close($ch);
    if (!$html) return '';
    if (preg_match('/<meta[^>]+property=["\']og:image["\'][^>]+content=["\'](https?:[^"\'>\s]+)["\']/', $html, $m)) return $m[1];
    if (preg_match('/<meta[^>]+name=["\']twitter:image["\'][^>]+content=["\'](https?:[^"\'>\s]+)["\']/', $html, $m)) return $m[1];
    return '';
}

// ── METHOD 1: NewsAPI.org ─────────────────────────────────────
if (in_array($source, ['newsapi', 'both'])) {

    $newsApiKey = getNewsApiKey();

    if ($newsApiKey) {
        $apiUrl = 'https://newsapi.org/v2/everything?' . http_build_query([
            'q'        => $query,
            'language' => 'en',
            'sortBy'   => 'publishedAt',
            'pageSize' => 10,
            'apiKey'   => $newsApiKey,
        ]);

        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT      => 'NewsForge/1.0 (news publishing platform)',
            CURLOPT_HTTPHEADER     => ['User-Agent: NewsForge/1.0 (news publishing platform)'],
        ]);
        $resp     = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200 && $resp) {
            $data = json_decode($resp, true);
            foreach ($data['articles'] ?? [] as $art) {
                if (($art['title'] ?? '') === '[Removed]') continue;
                $image = $art['urlToImage'] ?? '';
                if (!$image && !empty($art['url'])) {
                    $image = scrapeOgImage($art['url']);
                }
                $articles[] = [
                    'title'     => html_entity_decode($art['title'] ?? 'Untitled'),
                    'source'    => $art['source']['name'] ?? 'NewsAPI',
                    'date'      => !empty($art['publishedAt']) ? date('d M Y, H:i', strtotime($art['publishedAt'])) : 'Today',
                    'summary'   => substr(strip_tags($art['description'] ?? ''), 0, 200) . '...',
                    'content'   => trim(($art['description'] ?? '') . ' ' . ($art['content'] ?? '')),
                    'image'     => $image,
                    'url'       => $art['url'] ?? '',
                    'has_image' => !empty($image),
                ];
            }
            $usedSource = 'newsapi';
        } else {
            // Return error info so frontend can show it
            $errBody = json_decode($resp ?? '', true);
            $errMsg  = $errBody['message'] ?? "HTTP $httpCode";
            error_log("NewsForge NewsAPI error: $errMsg");
            if ($source === 'newsapi') {
                // Only NewsAPI was requested — return the error
                echo json_encode(['success' => false, 'error' => "NewsAPI error: $errMsg", 'articles' => []]);
                exit;
            }
            // If 'both' was requested, fall through to RSS
        }
    } else {
        if ($source === 'newsapi') {
            echo json_encode([
                'success' => false,
                'error'   => 'NewsAPI key not configured — add it in API Settings or config.php',
                'articles' => [],
            ]);
            exit;
        }
    }
}

// ── METHOD 2: Google News RSS ─────────────────────────────────
if (in_array($source, ['rss', 'both']) && empty($articles)) {

    $rssUrl   = 'https://news.google.com/rss/search?q=' . urlencode($query) . '&hl=en-IN&gl=IN&ceid=IN:en';
    $proxyUrl = 'https://api.rss2json.com/v1/api.json?rss_url=' . urlencode($rssUrl) . '&count=8';

    $ch = curl_init($proxyUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $resp = curl_exec($ch);
    curl_close($ch);

    if ($resp) {
        $data = json_decode($resp, true);
        foreach ($data['items'] ?? [] as $item) {
            $desc   = strip_tags($item['description'] ?? $item['content'] ?? '');
            $artUrl = $item['link'] ?? '';
            $image  = $item['thumbnail'] ?? $item['enclosure']['link'] ?? '';
            if (!$image && $artUrl) $image = scrapeOgImage($artUrl);
            if (!$image && !empty($item['description'])) {
                if (preg_match('/<img[^>]+src=["\'](https?:[^"\']+)["\']/', $item['description'], $m)) $image = $m[1];
            }
            $articles[] = [
                'title'     => html_entity_decode($item['title'] ?? 'Untitled'),
                'source'    => $item['author'] ?? parse_url($artUrl, PHP_URL_HOST) ?? 'Google News',
                'date'      => !empty($item['pubDate']) ? date('d M Y, H:i', strtotime($item['pubDate'])) : 'Today',
                'summary'   => substr($desc, 0, 200) . '...',
                'content'   => substr($desc, 0, 1000),
                'image'     => $image,
                'url'       => $artUrl,
                'has_image' => !empty($image),
            ];
        }
        $usedSource = 'rss';
    }
}

// ── METHOD 3: Mock fallback ───────────────────────────────────
if (empty($articles)) {
    $sources = ['The Hindu', 'Deccan Chronicle', 'NDTV', 'Times of India', 'Sakshi TV', 'ETV Bharat'];
    for ($i = 0; $i < 6; $i++) {
        $articles[] = [
            'title'     => "$query: " . ['Latest Developments', 'Regional Impact', 'Government Response', 'Expert Analysis', 'Ground Report', 'Full Coverage'][$i],
            'source'    => $sources[$i],
            'date'      => ['Today','2 hours ago','4 hours ago','Yesterday','3 hours ago','5 hours ago'][$i],
            'summary'   => "Breaking coverage of $query — comprehensive reporting from Andhra Pradesh and Telangana.",
            'content'   => "Breaking coverage of $query. Officials and community leaders have responded. The state government has announced measures. Experts believe this will have far-reaching consequences.",
            'image'     => '',
            'url'       => '',
            'has_image' => false,
        ];
    }
    $usedSource = 'mock';
}

echo json_encode([
    'success'      => true,
    'source'       => $usedSource,
    'articles'     => array_slice($articles, 0, NEWS_RESULTS_LIMIT),
]);

<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
header('Content-Type: application/json');

$input     = json_decode(file_get_contents('php://input'), true) ?? [];
$articleId = (int)($input['article_id'] ?? 0);
$body      = trim($input['generated_content'] ?? '');
$seoTitle  = trim($input['seo_title']         ?? '');
$metaDesc  = trim($input['meta_description']  ?? '');
$tags      = trim($input['tags']              ?? '');
$title     = trim($input['title']             ?? $seoTitle);

if (!$body) {
    echo json_encode(['error' => 'Content is empty']);
    exit;
}

$user = current_user();

Database::reconnect();

if ($articleId > 0) {
    // ── Update existing article ───────────────────────────────
    Database::query(
        "UPDATE articles SET
            generated_content = ?,
            seo_title         = ?,
            meta_description  = ?,
            tags              = ?
         WHERE id = ? AND (created_by = ? OR ? = 'admin')",
        [$body, $seoTitle, $metaDesc, $tags, $articleId, $user['id'], $user['role']]
    );
    log_activity('Article Updated', "Updated article #$articleId in editor");
    echo json_encode(['success' => true, 'article_id' => $articleId]);

} else {
    // ── Create new article (came directly to editor) ──────────
    Database::query(
        "INSERT INTO articles
            (title, seo_title, meta_description, generated_content, language, ai_engine, tags, status, created_by)
         VALUES (?, ?, ?, ?, 'English', 'manual', ?, 'ready', ?)",
        [$title ?: 'Untitled', $seoTitle, $metaDesc, $body, $tags, $user['id']]
    );
    $newId = Database::connect()->lastInsertId();
    log_activity('Article Created', "Created article #$newId via editor");
    echo json_encode(['success' => true, 'article_id' => $newId]);
}

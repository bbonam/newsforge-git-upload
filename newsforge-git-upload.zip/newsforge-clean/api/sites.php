<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();
header('Content-Type: application/json');

// Read the raw body ONCE and decode it
$rawBody = file_get_contents('php://input');
$input   = json_decode($rawBody, true) ?? [];

// Action can come from GET, POST form, or JSON body
$action = $_GET['action'] ?? $_POST['action'] ?? ($input['action'] ?? '');

switch ($action) {

    case 'list':
        $sites = Database::query("SELECT id,site_name,site_url,wp_username,default_category,status,created_date FROM wordpress_sites ORDER BY id")->fetchAll();
        echo json_encode(['success' => true, 'sites' => $sites]);
        break;

    case 'add':
        $name      = trim($input['site_name']        ?? '');
        $url       = rtrim(trim($input['site_url']   ?? ''), '/');
        $wpUser    = trim($input['wp_username']       ?? '');
        $wpPass    = trim($input['wp_password']       ?? '');
        $secretKey = trim($input['secret_key']        ?? '');
        $cat       = trim($input['default_category']  ?? '');
        $status    = in_array($input['status'] ?? '', ['active','inactive']) ? $input['status'] : 'active';

        if (!$name)  { echo json_encode(['error' => 'Site name is required']);  exit; }
        if (!$url)   { echo json_encode(['error' => 'Site URL is required']);   exit; }

        $exists = Database::query("SELECT id FROM wordpress_sites WHERE site_url=?", [$url])->fetch();
        if ($exists) { echo json_encode(['error' => 'A site with this URL already exists']); exit; }

        Database::query(
            "INSERT INTO wordpress_sites (site_name, site_url, wp_username, wp_password, secret_key, default_category, status)
             VALUES (?, ?, ?, ?, ?, ?, ?)",
            [$name, $url, $wpUser, $wpPass, $secretKey, $cat, $status]
        );
        $newId = Database::connect()->lastInsertId();
        log_activity('Site Added', "Added WP site: $name ($url)");
        echo json_encode(['success' => true, 'id' => $newId, 'message' => "Site \"$name\" added successfully"]);
        break;

    case 'edit':
        $id        = (int)($input['id'] ?? 0);
        $name      = trim($input['site_name']        ?? '');
        $url       = rtrim(trim($input['site_url']   ?? ''), '/');
        $wpUser    = trim($input['wp_username']       ?? '');
        $wpPass    = $input['wp_password']            ?? '';
        $secretKey = $input['secret_key']             ?? null;
        $cat       = trim($input['default_category']  ?? '');
        $status    = in_array($input['status'] ?? '', ['active','inactive']) ? $input['status'] : 'active';

        if (!$id)   { echo json_encode(['error' => 'Invalid site ID']); exit; }
        if (!$name) { echo json_encode(['error' => 'Site name is required']); exit; }

        // Build update dynamically — only update password/key if provided
        $fields = ['site_name=?','site_url=?','wp_username=?','default_category=?','status=?'];
        $params = [$name, $url, $wpUser, $cat, $status];

        if ($wpPass !== '') { $fields[] = 'wp_password=?';  $params[] = $wpPass; }
        if ($secretKey !== null && $secretKey !== '') { $fields[] = 'secret_key=?'; $params[] = $secretKey; }

        $params[] = $id;
        Database::query("UPDATE wordpress_sites SET " . implode(',', $fields) . " WHERE id=?", $params);
        log_activity('Site Updated', "Updated WP site ID $id: $name");
        echo json_encode(['success' => true, 'message' => "Site \"$name\" updated successfully"]);
        break;

    case 'delete':
        $id = (int)($input['id'] ?? 0);
        if (!$id) { echo json_encode(['error' => 'Invalid site ID']); exit; }
        $site = Database::query("SELECT site_name FROM wordpress_sites WHERE id=?", [$id])->fetch();
        Database::query("DELETE FROM wordpress_sites WHERE id=?", [$id]);
        log_activity('Site Deleted', "Deleted WP site: " . ($site['site_name'] ?? $id));
        echo json_encode(['success' => true]);
        break;

    case 'toggle':
        $id = (int)($input['id'] ?? 0);
        if (!$id) { echo json_encode(['error' => 'Invalid site ID']); exit; }
        Database::query("UPDATE wordpress_sites SET status = IF(status='active','inactive','active') WHERE id=?", [$id]);
        $newStatus = Database::query("SELECT status FROM wordpress_sites WHERE id=?", [$id])->fetch()['status'];
        echo json_encode(['success' => true, 'status' => $newStatus]);
        break;

    case 'get':
        $id = (int)($input['id'] ?? $_GET['id'] ?? 0);
        if (!$id) { echo json_encode(['error' => 'Invalid site ID']); exit; }

        // Check if secret_key column exists — safe for all MySQL versions
        $hasSK = false;
        try {
            $cols = Database::connect()->query("SHOW COLUMNS FROM wordpress_sites LIKE 'secret_key'")->fetchAll();
            $hasSK = !empty($cols);
        } catch (PDOException $e) {}

        $selectSK = $hasSK ? ", COALESCE(secret_key,'') as secret_key" : ", '' as secret_key";
        $site = Database::query(
            "SELECT id, site_name, site_url, wp_username, default_category, status $selectSK FROM wordpress_sites WHERE id=?",
            [$id]
        )->fetch();

        if (!$site) { echo json_encode(['error' => "Site #$id not found"]); exit; }
        echo json_encode(['success' => true, 'site' => $site]);
        break;

    case 'test_plugin':
        $url    = rtrim(trim($input['site_url']  ?? ''), '/');
        $secret = trim($input['secret_key']       ?? '');
        if (!$url)    { echo json_encode(['error' => 'Site URL is required']); exit; }
        if (!$secret) { echo json_encode(['error' => 'Secret key is required']); exit; }
        if (!preg_match('/^https?:\/\//', $url)) $url = 'https://' . $url;

        $ch = curl_init("$url/wp-json/newsforge/v1/ping");
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
            CURLOPT_POSTFIELDS     => '{}',
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'X-NewsForge-Key: ' . $secret],
            CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_USERAGENT => 'NewsForge/1.0',
        ]);
        $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); $cerr = curl_error($ch);
        curl_close($ch);

        if ($cerr)        { echo json_encode(['error' => "Connection error: $cerr"]); exit; }
        if ($code === 404) { echo json_encode(['error' => 'NewsForge Publisher plugin not found — is it installed and activated?']); exit; }
        if ($code === 403) { echo json_encode(['error' => 'Wrong secret key — check WP Admin → Settings → NewsForge Publisher']); exit; }
        $body = json_decode($resp, true);
        if ($code === 200 && !empty($body['success'])) {
            echo json_encode(['success' => true, 'message' => 'Plugin connected! ' . ($body['message'] ?? '')]);
        } else {
            echo json_encode(['error' => "Unexpected response (HTTP $code)"]);
        }
        break;

        $url    = rtrim(trim($input['site_url']   ?? ''), '/');
        $wpUser = trim($input['wp_username']       ?? '');
        $wpPass = trim($input['wp_password']       ?? '');

        if (!$url)    { echo json_encode(['error' => 'Site URL is required']); exit; }
        if (!$wpUser) { echo json_encode(['error' => 'WP Username is required']); exit; }
        if (!$wpPass) { echo json_encode(['error' => 'Application Password is required']); exit; }

        if (!preg_match('/^https?:\/\//', $url)) $url = 'https://' . $url;

        $authStr      = base64_encode("$wpUser:$wpPass");
        $testUrl      = "$url/wp-json/wp/v2/users/me";
        $commonOpts   = [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT => 'NewsForge/1.0',
        ];

        // Strategy 1 — Authorization header
        $ch = curl_init($testUrl);
        curl_setopt_array($ch, $commonOpts + [CURLOPT_HTTPHEADER => ['Authorization: Basic '.$authStr,'Accept: application/json']]);
        $resp = curl_exec($ch); $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); $curlErr = curl_error($ch);
        curl_close($ch);

        // Strategy 2 — credentials in URL (Hostinger/LiteSpeed fix)
        if ($httpCode === 401 && !$curlErr) {
            $urlWithCreds = str_replace('://', '://' . rawurlencode($wpUser) . ':' . rawurlencode($wpPass) . '@', $testUrl);
            $ch = curl_init($urlWithCreds);
            curl_setopt_array($ch, $commonOpts + [CURLOPT_HTTPHEADER => ['Accept: application/json']]);
            $resp2 = curl_exec($ch); $code2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($code2 === 200) { $resp = $resp2; $httpCode = $code2; }
        }

        if ($curlErr) {
            echo json_encode(['error' => "Connection error: $curlErr"]);
        } elseif ($httpCode === 200) {
            $userInfo = json_decode($resp, true);
            echo json_encode(['success' => true, 'message' => 'Connected as: ' . ($userInfo['name'] ?? $wpUser)]);
        } elseif ($httpCode === 401) {
            echo json_encode(['error' => 'Authentication failed (401) — wrong username or application password. On Hostinger add: SetEnvIf Authorization "(.*)" HTTP_AUTHORIZATION=$1 to .htaccess']);
        } elseif ($httpCode === 403) {
            echo json_encode(['error' => 'Access denied (403) — WP user needs Author role or higher']);
        } elseif ($httpCode === 404) {
            echo json_encode(['error' => 'REST API not found (404) — site URL should be just https://yourdomain.com']);
        } else {
            $body = json_decode($resp, true);
            echo json_encode(['error' => $body['message'] ?? "HTTP $httpCode — check site URL and credentials"]);
        }
        break;

    default:
        echo json_encode(['error' => "Unknown action: $action"]);
}

<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

$input     = json_decode(file_get_contents('php://input'), true) ?? [];
$title     = strip_tags(trim($input['title']   ?? 'Breaking News'));
$siteName  = strip_tags(trim($input['site_name'] ?? 'AP News Daily'));
$category  = strip_tags(trim($input['category'] ?? 'News'));
$articleId = (int)($input['article_id'] ?? 0);
$action    = $input['action'] ?? 'generate';

// ── Action: check if article already has an image ─────────────
if ($action === 'check') {
    if (!$articleId) { echo json_encode(['has_image' => false]); exit; }
    $art = Database::query("SELECT image_url FROM articles WHERE id=?", [$articleId])->fetch();
    echo json_encode(['has_image' => !empty($art['image_url'])]);
    exit;
}

// ── Generate branded SVG image ────────────────────────────────
// Truncate title for display
$displayTitle = mb_strlen($title) > 80 ? mb_substr($title, 0, 77) . '...' : $title;

// Wrap title into lines of ~35 chars
function wrapText(string $text, int $maxLen = 38): array {
    $words = explode(' ', $text);
    $lines = [];
    $line  = '';
    foreach ($words as $word) {
        if (mb_strlen($line . ' ' . $word) > $maxLen && $line) {
            $lines[] = trim($line);
            $line = $word;
        } else {
            $line .= ($line ? ' ' : '') . $word;
        }
    }
    if ($line) $lines[] = trim($line);
    return array_slice($lines, 0, 3); // max 3 lines
}

$titleLines = wrapText($displayTitle);
$lineCount  = count($titleLines);

// Color themes per category
$themes = [
    'default'       => ['bg1' => '#1a1a2e', 'bg2' => '#16213e', 'accent' => '#e94560'],
    'politics'      => ['bg1' => '#1e3a5f', 'bg2' => '#0d2137', 'accent' => '#f5a623'],
    'cricket'       => ['bg1' => '#1b4332', 'bg2' => '#0a2a1e', 'accent' => '#40c057'],
    'technology'    => ['bg1' => '#0f172a', 'bg2' => '#1e1b4b', 'accent' => '#818cf8'],
    'business'      => ['bg1' => '#1e293b', 'bg2' => '#0f172a', 'accent' => '#22d3ee'],
    'entertainment' => ['bg1' => '#3b0764', 'bg2' => '#1e0535', 'accent' => '#e879f9'],
    'education'     => ['bg1' => '#1c3a5e', 'bg2' => '#0f2444', 'accent' => '#60a5fa'],
];

$catKey = strtolower($category);
$theme  = $themes[$catKey] ?? $themes['default'];
foreach ($themes as $k => $t) {
    if (str_contains($catKey, $k)) { $theme = $t; break; }
}

$bg1    = $theme['bg1'];
$bg2    = $theme['bg2'];
$accent = $theme['accent'];

// Calculate title Y positions
$titleStartY = $lineCount === 1 ? 180 : ($lineCount === 2 ? 165 : 150);
$lineHeight  = 42;

// Build title SVG text elements
$titleSvg = '';
foreach ($titleLines as $i => $line) {
    $y = $titleStartY + ($i * $lineHeight);
    $escapedLine = htmlspecialchars($line, ENT_XML1);
    $titleSvg .= "<text x=\"400\" y=\"{$y}\" text-anchor=\"middle\" font-family=\"Georgia, serif\" font-size=\"32\" font-weight=\"bold\" fill=\"white\" filter=\"url(#shadow)\">{$escapedLine}</text>\n";
}

// Short site name for display (remove .com etc)
$shortName = preg_replace('/\.(com|net|org|in)$/i', '', $siteName);
$shortName = htmlspecialchars($shortName, ENT_XML1);
$catDisplay = htmlspecialchars(strtoupper($category), ENT_XML1);
$dateDisplay = date('d M Y');

// Generate the SVG
$svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:{$bg1}"/>
      <stop offset="100%" style="stop-color:{$bg2}"/>
    </linearGradient>
    <linearGradient id="overlay" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:rgba(0,0,0,0);stop-opacity:0"/>
      <stop offset="100%" style="stop-color:rgba(0,0,0,0.7);stop-opacity:1"/>
    </linearGradient>
    <filter id="shadow">
      <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="rgba(0,0,0,0.5)"/>
    </filter>
    <filter id="glow">
      <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
      <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>

  <!-- Background -->
  <rect width="1200" height="630" fill="url(#bg)"/>

  <!-- Decorative circles -->
  <circle cx="1050" cy="80"  r="180" fill="{$accent}" opacity="0.08"/>
  <circle cx="150"  cy="550" r="150" fill="{$accent}" opacity="0.06"/>
  <circle cx="600"  cy="315" r="400" fill="white"    opacity="0.02"/>

  <!-- Top accent bar -->
  <rect x="0" y="0" width="1200" height="6" fill="{$accent}"/>

  <!-- Category badge -->
  <rect x="80" y="60" width="180" height="36" rx="18" fill="{$accent}"/>
  <text x="170" y="84" text-anchor="middle" font-family="Arial, sans-serif"
        font-size="14" font-weight="bold" fill="white" letter-spacing="2">{$catDisplay}</text>

  <!-- Site name top right -->
  <text x="1120" y="84" text-anchor="end" font-family="Arial, sans-serif"
        font-size="18" font-weight="bold" fill="{$accent}" filter="url(#glow)">{$shortName}</text>

  <!-- Decorative line under category -->
  <line x1="80" y1="115" x2="400" y2="115" stroke="{$accent}" stroke-width="1.5" opacity="0.4"/>

  <!-- Main title -->
  {$titleSvg}

  <!-- Bottom bar -->
  <rect x="0" y="555" width="1200" height="75" fill="rgba(0,0,0,0.5)"/>

  <!-- Site branding bottom left -->
  <circle cx="110" cy="592" r="22" fill="{$accent}"/>
  <text x="110" y="598" text-anchor="middle" font-family="Georgia, serif"
        font-size="16" font-weight="bold" fill="white">{$shortName[0]}</text>
  <text x="145" y="586" font-family="Arial, sans-serif" font-size="18"
        font-weight="bold" fill="white">{$shortName}</text>
  <text x="145" y="606" font-family="Arial, sans-serif" font-size="13"
        fill="rgba(255,255,255,0.6)">Breaking News &amp; Updates</text>

  <!-- Date bottom right -->
  <text x="1120" y="598" text-anchor="end" font-family="Arial, sans-serif"
        font-size="14" fill="rgba(255,255,255,0.5)">{$dateDisplay}</text>

  <!-- Watermark -->
  <text x="1120" y="618" text-anchor="end" font-family="Arial, sans-serif"
        font-size="11" fill="rgba(255,255,255,0.25)">NewsForge AI</text>
</svg>
SVG;

// ── Save SVG as PNG-equivalent to uploads, update DB ──────────
$filename  = 'nf-img-' . ($articleId ?: uniqid()) . '-' . time() . '.svg';
$uploadDir = UPLOAD_DIR;
$filePath  = rtrim($uploadDir, '/') . '/' . $filename;
$fileUrl   = rtrim(APP_URL, '/') . '/uploads/images/' . $filename;

header('Content-Type: application/json');

if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);

if (file_put_contents($filePath, $svg)) {
    // Update article image_url in DB
    if ($articleId) {
        Database::reconnect();
        Database::query("UPDATE articles SET image_url=? WHERE id=?", [$fileUrl, $articleId]);
    }
    echo json_encode([
        'success'   => true,
        'image_url' => $fileUrl,
        'filename'  => $filename,
        'message'   => 'Branded image generated',
    ]);
} else {
    // Return SVG as data URL if file save fails (permissions issue)
    $dataUrl = 'data:image/svg+xml;base64,' . base64_encode($svg);
    echo json_encode([
        'success'   => true,
        'image_url' => $dataUrl,
        'message'   => 'Image generated (inline)',
    ]);
}

<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$pageTitle='Proof Reading Editor';$activePage='editor';
include __DIR__ . '/includes/layout.php';
?>
<div style="display:grid;grid-template-columns:1fr 340px;gap:20px">
<div class="card" style="overflow:hidden">
  <div class="card-header">
    <span><i class="fa fa-edit" style="color:#e94560;margin-right:8px"></i>Article Editor</span>
    <div style="display:flex;gap:8px">
      <button class="btn-sec btn-sm-nf" onclick="saveDraft()"><i class="fa fa-save"></i> Save Draft</button>
      <button class="btn-primary-nf btn-sm-nf" onclick="goPublish()"><i class="fa fa-paper-plane"></i> Publish</button>
    </div>
  </div>
  <div id="toolbar" style="display:flex;flex-wrap:wrap;gap:4px;padding:10px;border-bottom:1px solid var(--border)">
    <?php
    $btns=[['bold','B'],['italic','I'],['underline','U'],['|'],['formatBlock:h2','H2'],['formatBlock:h3','H3'],['|'],
           ['insertUnorderedList','<i class="fa fa-list-ul"></i>'],['insertOrderedList','<i class="fa fa-list-ol"></i>'],
           ['|'],['justifyLeft','<i class="fa fa-align-left"></i>'],['justifyCenter','<i class="fa fa-align-center"></i>'],
           ['|'],['undo','<i class="fa fa-undo"></i>'],['redo','<i class="fa fa-redo"></i>'],['|'],['removeFormat','<i class="fa fa-eraser"></i>']];
    foreach ($btns as $b) {
      if ($b[0]==='|') { echo '<div style="width:1px;height:32px;background:var(--border);margin:0 4px"></div>'; continue; }
      [$cmd,$label]=explode(':',$b[0],2)+[$b[0],''];
      $cmdArg=str_contains($b[0],':') ? "'".explode(':',$b[0])[1]."'" : 'null';
      echo "<button onclick=\"exec('{$cmd}',{$cmdArg})\" style=\"width:32px;height:32px;border:1px solid var(--border);border-radius:6px;background:white;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600;color:var(--text2)\">{$b[1]}</button>";
    }
    ?>
  </div>
  <div id="editor" contenteditable="true" oninput="wc()"
       style="min-height:380px;padding:20px;outline:none;font-size:14px;line-height:1.8"></div>
  <div style="padding:8px 16px;background:#f8f9fb;border-top:1px solid var(--border);display:flex;justify-content:space-between;font-size:12px;color:#9ca3af">
    <span id="wc-words">0 words</span><span id="wc-chars">0 chars</span>
  </div>
</div>

<div>
  <div class="card mb-3">
    <div class="card-header">Metadata</div>
    <div class="card-body">
      <div class="form-group"><label>SEO Title</label><input type="text" class="inp" id="meta-title" placeholder="SEO title..."></div>
      <div class="form-group"><label>Meta Description</label><textarea class="inp" rows="2" id="meta-desc" placeholder="Max 160 chars..."></textarea><div style="font-size:11px;color:#9ca3af;margin-top:3px" id="mc">0/160</div></div>
      <div class="form-group mb-0"><label>Tags</label><input type="text" class="inp" id="meta-tags" placeholder="tag1, tag2, tag3" oninput="renderTags()">
      <div id="tag-display" style="margin-top:6px"></div></div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">Featured Image</div>
    <div class="card-body">
      <!-- Upload box -->
      <div id="img-box" onclick="document.getElementById('img-file').click()"
           style="width:100%;height:140px;border:2px dashed #e5e7eb;border-radius:10px;
                  display:flex;flex-direction:column;align-items:center;justify-content:center;
                  cursor:pointer;overflow:hidden;position:relative;background:#f8f9fb;transition:.2s">
        <div id="img-placeholder" style="text-align:center;color:#9ca3af;pointer-events:none">
          <i class="fa fa-cloud-upload-alt" style="font-size:26px;display:block;margin-bottom:6px"></i>
          <div style="font-size:13px;font-weight:500">Click to upload image</div>
          <div style="font-size:11px;margin-top:3px">JPG, PNG, WebP · Max 5MB</div>
        </div>
        <img id="img-preview" src="" alt=""
             style="display:none;width:100%;height:100%;object-fit:cover;position:absolute;top:0;left:0">
      </div>
      <input type="file" id="img-file" accept="image/jpeg,image/png,image/webp,image/gif"
             style="display:none" onchange="onImgSelected(this)">
      <div id="img-actions" style="display:none;margin-top:8px;align-items:center;justify-content:space-between">
        <span style="font-size:12px;color:#10b981"><i class="fa fa-check-circle"></i> <span id="img-fname"></span></span>
        <button class="btn-sec btn-sm-nf" style="font-size:12px" onclick="removeImg(event)">
          <i class="fa fa-times"></i> Remove
        </button>
      </div>
    </div>
  </div>
</div>
</div>

<script>
// ── Editor helpers ────────────────────────────────────────────
function exec(cmd,val=null){document.execCommand(cmd,false,val);document.getElementById('editor').focus()}
function wc(){
  const t=document.getElementById('editor').innerText||'';
  document.getElementById('wc-words').textContent=t.trim().split(/\s+/).filter(w=>w).length+' words';
  document.getElementById('wc-chars').textContent=t.length+' chars';
}
document.getElementById('meta-desc').addEventListener('input',function(){
  document.getElementById('mc').textContent=this.value.length+'/160';
});
function renderTags(){
  const v=document.getElementById('meta-tags').value;
  document.getElementById('tag-display').innerHTML=v.split(',').filter(t=>t.trim())
    .map(t=>`<span style="display:inline-block;background:#f1f3f7;color:var(--text2);border-radius:20px;padding:2px 8px;font-size:11px;margin:2px">${t.trim()}</span>`).join('');
}

// ── Image upload ──────────────────────────────────────────────
let imgBase64 = '';

function onImgSelected(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 5*1024*1024) { showToast('Max 5MB','error'); input.value=''; return; }
  const reader = new FileReader();
  reader.onload = e => {
    imgBase64 = e.target.result.split(',')[1];
    document.getElementById('img-preview').src = e.target.result;
    document.getElementById('img-preview').style.display = 'block';
    document.getElementById('img-placeholder').style.display = 'none';
    document.getElementById('img-box').style.borderColor = '#10b981';
    document.getElementById('img-box').style.borderStyle = 'solid';
    document.getElementById('img-fname').textContent = file.name;
    document.getElementById('img-actions').style.display = 'flex';
  };
  reader.readAsDataURL(file);
}

function removeImg(e) {
  e.stopPropagation();
  imgBase64 = '';
  document.getElementById('img-file').value = '';
  document.getElementById('img-preview').style.display = 'none';
  document.getElementById('img-preview').src = '';
  document.getElementById('img-placeholder').style.display = 'block';
  document.getElementById('img-box').style.borderColor = '#e5e7eb';
  document.getElementById('img-box').style.borderStyle = 'dashed';
  document.getElementById('img-actions').style.display = 'none';
}

// ── Load from sessionStorage ──────────────────────────────────
const ed = sessionStorage.getItem('editorContent');
if (ed) {
  const d = JSON.parse(ed);
  document.getElementById('editor').innerHTML     = d.body            || '';
  document.getElementById('meta-title').value     = d.seoTitle        || '';
  document.getElementById('meta-desc').value      = d.metaDescription || '';
  document.getElementById('meta-tags').value      = d.tags            || '';
  wc(); renderTags();
}

// ── Save Draft ────────────────────────────────────────────────
function saveDraft() {
  const d = {
    body:            document.getElementById('editor').innerHTML,
    seoTitle:        document.getElementById('meta-title').value,
    metaDescription: document.getElementById('meta-desc').value,
    tags:            document.getElementById('meta-tags').value,
  };
  sessionStorage.setItem('editorContent', JSON.stringify(d));
  showToast('Draft saved','success');
}

// ── Publish — save edits to DB then go to publish page ────────
async function goPublish() {
  const artId = sessionStorage.getItem('publishArticleId');

  const body      = document.getElementById('editor').innerHTML.trim();
  const seoTitle  = document.getElementById('meta-title').value.trim();
  const metaDesc  = document.getElementById('meta-desc').value.trim();
  const tags      = document.getElementById('meta-tags').value.trim();

  if (!body) { showToast('Editor is empty — nothing to publish','error'); return; }

  // Save edits to sessionStorage so publish page has latest content
  const updated = { body, seoTitle, metaDescription: metaDesc, tags };
  sessionStorage.setItem('editorContent', JSON.stringify(updated));

  // If image uploaded, store base64 for publish page
  if (imgBase64) {
    sessionStorage.setItem('editorImageBase64', imgBase64);
  }

  // If we have an article ID — update it in DB with latest edits
  if (artId) {
    try {
      await fetch('api/editor_save.php', {
        method:  'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          article_id:       parseInt(artId),
          generated_content: body,
          seo_title:        seoTitle,
          meta_description: metaDesc,
          tags:             tags,
        })
      });
    } catch(e) { /* non-fatal — session storage fallback still works */ }
    window.location.href = 'publish.php';
    return;
  }

  // No article ID — save as new article then go to publish
  const btn = document.querySelector('.btn-primary-nf');
  if(btn){btn.disabled=true;btn.innerHTML='<i class="fa fa-spinner fa-spin"></i> Saving...';}

  try {
    const resp = await fetch('api/editor_save.php', {
      method:  'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        article_id:        0,   // 0 = create new
        generated_content: body,
        seo_title:         seoTitle,
        meta_description:  metaDesc,
        tags:              tags,
        title:             seoTitle || 'Untitled',
      })
    });
    const data = await resp.json();
    if (data.article_id) {
      sessionStorage.setItem('publishArticleId', data.article_id);
      // Also update generatedArticle in session
      const gen = JSON.parse(sessionStorage.getItem('generatedArticle') || '{}');
      gen.seoTitle        = seoTitle;
      gen.body            = body;
      gen.metaDescription = metaDesc;
      gen.tags            = tags;
      gen.article_id      = data.article_id;
      sessionStorage.setItem('generatedArticle', JSON.stringify(gen));
      window.location.href = 'publish.php';
    } else {
      showToast(data.error || 'Could not save article','error');
    }
  } catch(e) {
    showToast('Save failed: '+e.message,'error');
  } finally {
    if(btn){btn.disabled=false;btn.innerHTML='<i class="fa fa-paper-plane"></i> Publish';}
  }
}
</script>
<?php require __DIR__ . '/includes/layout_footer.php'; ?>
